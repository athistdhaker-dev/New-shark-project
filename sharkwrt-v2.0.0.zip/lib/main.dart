import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import 'core/theme.dart';
import 'screens/router_list.dart';
import 'state/app_state.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  final state = AppState();
  await state.init();
  runApp(ChangeNotifierProvider<AppState>.value(
    value: state,
    child: const SharkApp(),
  ));
}

class SharkApp extends StatelessWidget {
  const SharkApp({super.key});

  @override
  Widget build(BuildContext context) {
    final s = context.watch<AppState>();
    return MaterialApp(
      title: 'SharkWRT',
      navigatorKey: s.navKey,
      debugShowCheckedModeBanner: false,
      theme: buildTheme(s.theme, s.accent),
      home: const RouterListScreen(),
    );
  }
}

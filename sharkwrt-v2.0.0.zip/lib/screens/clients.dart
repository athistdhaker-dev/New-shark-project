import 'dart:async';

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../core/ui.dart';
import '../data/router_api.dart';
import '../state/app_state.dart';

class ClientsTab extends StatefulWidget {
  const ClientsTab({super.key});

  @override
  State<ClientsTab> createState() => _ClientsTabState();
}

class _ClientsTabState extends State<ClientsTab> {
  ClientsData? _data;
  String? _error;
  String _filter = 'All';
  Timer? _timer;
  bool _busy = false;

  @override
  void initState() {
    super.initState();
    _load();
    _timer = Timer.periodic(const Duration(seconds: 12), (_) => _load());
  }

  @override
  void dispose() {
    _timer?.cancel();
    super.dispose();
  }

  Future<void> _load() async {
    if (_busy) return;
    final api = context.read<AppState>().api;
    if (api == null) return;
    _busy = true;
    try {
      final d = await api.loadClients();
      if (mounted) {
        setState(() {
          _data = d;
          _error = null;
        });
      }
    } catch (e) {
      if (mounted) setState(() => _error = e.toString());
    } finally {
      _busy = false;
    }
  }

  String _name(NetClient c) {
    final a = context.read<AppState>().alias(c.mac);
    if (a != null && a.isNotEmpty) return a;
    if (c.hostname.isNotEmpty) return c.hostname;
    return 'Unknown device';
  }

  Color _bandColor(String b) {
    if (b == '5G') return const Color(0xFFA78BFA);
    if (b == '6G') return const Color(0xFFFB7185);
    if (b == 'LAN') return const Color(0xFF4DA3FF);
    return const Color(0xFF34D399);
  }

  Future<void> _block(NetClient c, bool block) async {
    final api = context.read<AppState>().api;
    if (api == null) return;
    try {
      if (block) {
        await api.blockMac(c.mac, ip: c.ip);
      } else {
        await api.unblockMac(c.mac);
      }
      if (mounted) {
        showMsg(context, block ? 'Internet band kar diya' : 'Unblock ho gaya');
      }
      await _load();
    } catch (e) {
      if (mounted) showMsg(context, e.toString());
    }
  }

  Future<void> _unblockMac(String mac) async {
    final api = context.read<AppState>().api;
    if (api == null) return;
    try {
      await api.unblockMac(mac);
      if (mounted) showMsg(context, 'Unblock ho gaya');
      await _load();
    } catch (e) {
      if (mounted) showMsg(context, e.toString());
    }
  }

  void _sheet(NetClient c) {
    final blocked = _data?.blocked.containsKey(c.mac) ?? false;
    showModalBottomSheet<void>(
      context: context,
      builder: (ctx) => SafeArea(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            ListTile(
              title: Text(_name(c),
                  style: const TextStyle(fontWeight: FontWeight.w800)),
              subtitle: Text('${c.ip}  •  ${c.mac}'),
            ),
            ListTile(
              leading: const Icon(Icons.edit_outlined),
              title: const Text('Naam badlo'),
              onTap: () async {
                Navigator.pop(ctx);
                final v = await askText(context, 'Device ka naam',
                    initial: _name(c) == 'Unknown device' ? '' : _name(c));
                if (v != null && mounted) {
                  await context.read<AppState>().setAlias(c.mac, v);
                }
              },
            ),
            ListTile(
              leading: Icon(
                  blocked ? Icons.lock_open_outlined : Icons.block_outlined,
                  color: blocked ? Colors.greenAccent : Colors.redAccent),
              title: Text(blocked ? 'Unblock (internet chalu)' : 'Block (internet band)'),
              onTap: () async {
                Navigator.pop(ctx);
                if (!blocked) {
                  final ok = await confirmDialog(context, 'Block?',
                      '${_name(c)} ka internet band ho jayega (LAN access rahega).',
                      ok: 'Block');
                  if (!ok) return;
                }
                await _block(c, !blocked);
              },
            ),
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final s = context.watch<AppState>();
    final t = s.theme;
    final d = _data;
    if (d == null) {
      return _error != null
          ? ErrorBox(_error!, onRetry: _load)
          : const Center(child: CircularProgressIndicator());
    }
    final list = d.clients
        .where((c) => _filter == 'All' || c.band == _filter)
        .toList();
    return RefreshIndicator(
      onRefresh: _load,
      child: ListView(
        padding: const EdgeInsets.fromLTRB(16, 8, 16, 24),
        children: [
          Wrap(
            spacing: 8,
            children: [
              for (final f in ['All', '5G', '2.4G', 'LAN'])
                ChoiceChip(
                  label: Text(f),
                  selected: _filter == f,
                  onSelected: (_) => setState(() => _filter = f),
                ),
            ],
          ),
          SectionTitle('Connected (${list.length})'),
          if (list.isEmpty) const GlassCard(child: Text('Koi device nahi mila')),
          for (final c in list)
            GlassCard(
              onTap: () => _sheet(c),
              child: Row(
                children: [
                  Icon(
                    c.band == 'LAN' ? Icons.settings_ethernet : Icons.smartphone,
                    color: _bandColor(c.band),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(_name(c),
                            style: const TextStyle(
                                fontWeight: FontWeight.w700, fontSize: 15)),
                        const SizedBox(height: 2),
                        Text(
                          '${c.ip.isEmpty ? '-' : c.ip}  •  ${c.mac}',
                          style: TextStyle(color: t.sub, fontSize: 12),
                        ),
                      ],
                    ),
                  ),
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.end,
                    children: [
                      Pill(c.band, _bandColor(c.band)),
                      if (c.signal != null)
                        Padding(
                          padding: const EdgeInsets.only(top: 4),
                          child: Text('${c.signal} dBm',
                              style: TextStyle(color: t.sub, fontSize: 11)),
                        ),
                      if (d.blocked.containsKey(c.mac))
                        const Padding(
                          padding: EdgeInsets.only(top: 4),
                          child: Pill('BLOCKED', Colors.redAccent),
                        ),
                    ],
                  ),
                ],
              ),
            ),
          if (d.blocked.isNotEmpty) ...[
            SectionTitle('Blocked (${d.blocked.length})'),
            for (final e in d.blocked.entries)
              GlassCard(
                child: Row(
                  children: [
                    const Icon(Icons.block, color: Colors.redAccent),
                    const SizedBox(width: 12),
                    Expanded(
                      child: Text(
                        (s.alias(e.key) ?? '').isNotEmpty
                            ? '${s.alias(e.key)}  •  ${e.key}'
                            : e.key,
                      ),
                    ),
                    TextButton(
                      onPressed: () => _unblockMac(e.key),
                      child: const Text('Unblock'),
                    ),
                  ],
                ),
              ),
          ],
        ],
      ),
    );
  }
}

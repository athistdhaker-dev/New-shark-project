import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../core/theme.dart';
import '../core/ui.dart';
import '../state/app_state.dart';

class SettingsScreen extends StatelessWidget {
  const SettingsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final s = context.watch<AppState>();
    final t = s.theme;
    return GlassScaffold(
      title: 'App settings',
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          const SectionTitle('Theme'),
          for (var i = 0; i < kThemes.length; i++)
            GlassCard(
              onTap: () => s.setTheme(i),
              child: Row(
                children: [
                  Container(
                    width: 44,
                    height: 28,
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(8),
                      gradient: LinearGradient(colors: kThemes[i].bg),
                      border: Border.all(color: t.border),
                    ),
                  ),
                  const SizedBox(width: 14),
                  Expanded(
                    child: Text(kThemes[i].name,
                        style: const TextStyle(fontWeight: FontWeight.w700)),
                  ),
                  if (s.themeIndex == i) Icon(Icons.check_circle, color: s.accent),
                ],
              ),
            ),
          const SectionTitle('Accent color'),
          GlassCard(
            child: Wrap(
              spacing: 14,
              runSpacing: 10,
              children: [
                for (var i = 0; i < kAccents.length; i++)
                  GestureDetector(
                    onTap: () => s.setAccent(i),
                    child: Container(
                      width: 38,
                      height: 38,
                      decoration: BoxDecoration(
                        color: kAccents[i],
                        shape: BoxShape.circle,
                        border: Border.all(
                          color: s.accentIndex == i ? t.text : Colors.transparent,
                          width: 3,
                        ),
                      ),
                    ),
                  ),
              ],
            ),
          ),
          const SectionTitle('Effects'),
          GlassCard(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 4),
            child: SwitchListTile(
              contentPadding: EdgeInsets.zero,
              title: const Text('Glass blur'),
              subtitle: Text('Slow phone par band kar do',
                  style: TextStyle(color: t.sub, fontSize: 12)),
              value: s.blur,
              onChanged: s.setBlur,
            ),
          ),
          const SectionTitle('About'),
          GlassCard(
            child: Text(
              'SharkWRT 1.0.0\nSSH se OpenWrt control. Koi cloud / analytics nahi; credentials sirf is phone ke Keystore me.',
              style: TextStyle(color: t.sub),
            ),
          ),
        ],
      ),
    );
  }
}

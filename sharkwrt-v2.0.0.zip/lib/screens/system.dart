import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../core/ui.dart';
import '../data/router_api.dart';
import '../state/app_state.dart';

class ServicesScreen extends StatefulWidget {
  const ServicesScreen({super.key});

  @override
  State<ServicesScreen> createState() => _ServicesScreenState();
}

class _ServicesScreenState extends State<ServicesScreen> {
  List<ServiceItem>? _list;
  String? _error;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final api = context.read<AppState>().api;
    if (api == null) return;
    try {
      final l = await api.loadServices();
      if (mounted) {
        setState(() {
          _list = l;
          _error = null;
        });
      }
    } catch (e) {
      if (mounted) setState(() => _error = e.toString());
    }
  }

  Future<void> _act(String name, String action) async {
    final api = context.read<AppState>().api;
    if (api == null) return;
    try {
      await api.serviceAction(name, action);
      if (mounted) showMsg(context, '$name: $action ho gaya');
      if (action == 'enable' || action == 'disable') await _load();
    } catch (e) {
      if (mounted) showMsg(context, e.toString());
    }
  }

  @override
  Widget build(BuildContext context) {
    final l = _list;
    Widget body;
    if (l == null) {
      body = _error != null
          ? ErrorBox(_error!, onRetry: _load)
          : const Center(child: CircularProgressIndicator());
    } else {
      body = RefreshIndicator(
        onRefresh: _load,
        child: ListView(
          padding: const EdgeInsets.all(16),
          children: [
            for (final s in l)
              GlassCard(
                padding: const EdgeInsets.fromLTRB(16, 6, 6, 6),
                child: Row(
                  children: [
                    Expanded(
                      child: Text(s.name,
                          style: const TextStyle(fontWeight: FontWeight.w700)),
                    ),
                    Text(s.enabled ? 'boot: on' : 'boot: off',
                        style: TextStyle(
                            fontSize: 12,
                            color: s.enabled ? Colors.greenAccent : Colors.grey)),
                    PopupMenuButton<String>(
                      onSelected: (a) async {
                        if (a == 'stop' || a == 'disable') {
                          final ok = await confirmDialog(
                              context, '${s.name} $a?', 'Pakka?');
                          if (!ok) return;
                        }
                        await _act(s.name, a);
                      },
                      itemBuilder: (_) => [
                        const PopupMenuItem(value: 'start', child: Text('Start')),
                        const PopupMenuItem(value: 'stop', child: Text('Stop')),
                        const PopupMenuItem(
                            value: 'restart', child: Text('Restart')),
                        PopupMenuItem(
                            value: s.enabled ? 'disable' : 'enable',
                            child: Text(s.enabled ? 'Disable on boot' : 'Enable on boot')),
                      ],
                    ),
                  ],
                ),
              ),
          ],
        ),
      );
    }
    return GlassScaffold(title: 'Services', body: body);
  }
}

class LogsScreen extends StatefulWidget {
  const LogsScreen({super.key});

  @override
  State<LogsScreen> createState() => _LogsScreenState();
}

class _LogsScreenState extends State<LogsScreen> {
  String? _text;
  String? _error;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final api = context.read<AppState>().api;
    if (api == null) return;
    try {
      final t = await api.logs();
      if (mounted) {
        setState(() {
          _text = t;
          _error = null;
        });
      }
    } catch (e) {
      if (mounted) setState(() => _error = e.toString());
    }
  }

  @override
  Widget build(BuildContext context) {
    Widget body;
    if (_text == null) {
      body = _error != null
          ? ErrorBox(_error!, onRetry: _load)
          : const Center(child: CircularProgressIndicator());
    } else {
      body = RefreshIndicator(
        onRefresh: _load,
        child: ListView(
          padding: const EdgeInsets.all(12),
          children: [
            SelectableText(
              _text!.trim().isEmpty ? '(log khali)' : _text!,
              style: const TextStyle(fontFamily: 'monospace', fontSize: 11),
            ),
          ],
        ),
      );
    }
    return GlassScaffold(
      title: 'Logs',
      actions: [
        IconButton(icon: const Icon(Icons.refresh), onPressed: _load),
      ],
      body: body,
    );
  }
}

class SystemScreen extends StatelessWidget {
  const SystemScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final s = context.watch<AppState>();
    final api = s.api;
    final t = s.theme;
    return GlassScaffold(
      title: 'System',
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          GlassCard(
            onTap: api == null
                ? null
                : () async {
                    final v = await askText(context, 'Hostname',
                        initial: s.info.hostname, hint: 'jaise OpenWrt');
                    if (v == null || v.isEmpty) return;
                    try {
                      await api.setHostname(v);
                      if (context.mounted) showMsg(context, 'Hostname badal gaya');
                    } catch (e) {
                      if (context.mounted) showMsg(context, e.toString());
                    }
                  },
            child: Row(
              children: [
                const Icon(Icons.badge_outlined),
                const SizedBox(width: 14),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const Text('Hostname',
                          style: TextStyle(fontWeight: FontWeight.w700)),
                      Text(s.info.hostname.isEmpty ? '-' : s.info.hostname,
                          style: TextStyle(color: t.sub, fontSize: 12)),
                    ],
                  ),
                ),
                Icon(Icons.edit_outlined, color: t.sub),
              ],
            ),
          ),
          const SizedBox(height: 8),
          HoldButton(
            label: 'Hold to reboot',
            icon: Icons.power_settings_new,
            color: Colors.redAccent,
            onConfirmed: () async {
              if (api == null) return;
              try {
                await api.reboot();
                if (context.mounted) showMsg(context, 'Router reboot ho raha hai');
              } catch (e) {
                if (context.mounted) showMsg(context, e.toString());
              }
            },
          ),
        ],
      ),
    );
  }
}

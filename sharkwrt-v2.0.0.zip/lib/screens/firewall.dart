import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../core/ui.dart';
import '../data/router_api.dart';
import '../state/app_state.dart';

class FirewallScreen extends StatefulWidget {
  const FirewallScreen({super.key});

  @override
  State<FirewallScreen> createState() => _FirewallScreenState();
}

class _FirewallScreenState extends State<FirewallScreen> {
  FirewallData? _data;
  String? _error;

  @override
  void initState() {
    super.initState();
    _load();
  }

  RouterApi? get _api => context.read<AppState>().api;

  Future<void> _load() async {
    final api = _api;
    if (api == null) return;
    try {
      final d = await api.loadFirewall();
      if (mounted) {
        setState(() {
          _data = d;
          _error = null;
        });
      }
    } catch (e) {
      if (mounted) setState(() => _error = e.toString());
    }
  }

  Future<void> _do(Future<void> Function() fn, [String? done]) async {
    try {
      await fn();
      if (done != null && mounted) showMsg(context, done);
      await _load();
    } catch (e) {
      if (mounted) showMsg(context, e.toString());
    }
  }

  Future<void> _add(bool isRule) async {
    final api = _api;
    if (api == null) return;
    final r = await showDialog<Map<String, String>>(
      context: context,
      builder: (_) => _FwAddDialog(isRule: isRule),
    );
    if (r == null) return;
    if (isRule) {
      await _do(
        () => api.addTrafficRule(
          name: r['name'] ?? '',
          proto: r['proto'] ?? 'tcp',
          destPort: r['port'] ?? '',
          target: r['target'] ?? 'ACCEPT',
        ),
        'Stage ho gaya. Neeche Apply dabao.',
      );
    } else {
      await _do(
        () => api.addPortForward(
          name: r['name'] ?? '',
          proto: r['proto'] ?? 'tcp',
          extPort: r['port'] ?? '',
          destIp: r['ip'] ?? '',
          destPort: r['dport'] ?? '',
        ),
        'Stage ho gaya. Neeche Apply dabao.',
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    final t = context.watch<AppState>().theme;
    final api = _api;
    final d = _data;
    Widget body;
    if (d == null) {
      body = _error != null
          ? ErrorBox(_error!, onRetry: _load)
          : const Center(child: CircularProgressIndicator());
    } else {
      final forwards = d.cfg.ofType('redirect').toList();
      final rules = d.cfg
          .ofType('rule')
          .where((s) => !s.name.startsWith('swblk_'))
          .toList();
      final zones = d.cfg.ofType('zone').toList();
      body = RefreshIndicator(
        onRefresh: _load,
        child: ListView(
          padding: const EdgeInsets.fromLTRB(16, 8, 16, 24),
          children: [
            if (d.changes.isNotEmpty)
              GlassCard(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      '${d.changes.length} badlav pending (router par abhi lagu nahi)',
                      style: const TextStyle(fontWeight: FontWeight.w800),
                    ),
                    const SizedBox(height: 6),
                    Text(
                      d.changes.take(8).join('\n'),
                      maxLines: 8,
                      overflow: TextOverflow.ellipsis,
                      style: TextStyle(
                          fontFamily: 'monospace', fontSize: 11, color: t.sub),
                    ),
                    const SizedBox(height: 10),
                    Row(
                      children: [
                        Expanded(
                          child: FilledButton(
                            onPressed: api == null
                                ? null
                                : () => _do(api.fwApply, 'Apply ho gaya'),
                            child: const Text('Apply'),
                          ),
                        ),
                        const SizedBox(width: 10),
                        Expanded(
                          child: OutlinedButton(
                            onPressed: api == null
                                ? null
                                : () => _do(api.fwDiscard, 'Badlav discard ho gaye'),
                            child: const Text('Discard'),
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            SectionTitle('Port forwards',
                trailing: TextButton(
                    onPressed: () => _add(false), child: const Text('+ Add'))),
            if (forwards.isEmpty)
              const GlassCard(child: Text('Koi port forward nahi')),
            for (final f in forwards)
              GlassCard(
                child: Row(
                  children: [
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            (f.o('name') ?? '').isEmpty ? f.name : f.o('name')!,
                            style: const TextStyle(fontWeight: FontWeight.w700),
                          ),
                          Text(
                            '${f.o('proto') ?? 'tcp udp'}  ${f.o('src_dport') ?? '?'}  ->  ${f.o('dest_ip') ?? '?'}:${f.o('dest_port') ?? f.o('src_dport') ?? '?'}',
                            style: TextStyle(color: t.sub, fontSize: 12),
                          ),
                        ],
                      ),
                    ),
                    Switch(
                      value: f.o('enabled') != '0',
                      onChanged: api == null
                          ? null
                          : (v) => _do(() => api.fwToggle(f.name, v)),
                    ),
                    IconButton(
                      icon: const Icon(Icons.delete_outline,
                          color: Colors.redAccent),
                      onPressed:
                          api == null ? null : () => _do(() => api.fwDelete(f.name)),
                    ),
                  ],
                ),
              ),
            SectionTitle('Traffic rules',
                trailing: TextButton(
                    onPressed: () => _add(true), child: const Text('+ Add'))),
            if (rules.isEmpty) const GlassCard(child: Text('Koi rule nahi')),
            for (final r in rules)
              GlassCard(
                child: Row(
                  children: [
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            (r.o('name') ?? '').isEmpty ? r.name : r.o('name')!,
                            style: const TextStyle(fontWeight: FontWeight.w700),
                          ),
                          const SizedBox(height: 4),
                          Wrap(
                            spacing: 6,
                            children: [
                              Pill(
                                r.o('target') ?? 'ACCEPT',
                                (r.o('target') ?? 'ACCEPT') == 'ACCEPT'
                                    ? Colors.greenAccent
                                    : Colors.redAccent,
                              ),
                              if (r.o('proto') != null)
                                Pill(r.o('proto')!, Colors.blueGrey),
                              if (r.o('dest_port') != null)
                                Pill('port ${r.o('dest_port')}', Colors.blueGrey),
                            ],
                          ),
                        ],
                      ),
                    ),
                    Switch(
                      value: r.o('enabled') != '0',
                      onChanged: api == null
                          ? null
                          : (v) => _do(() => api.fwToggle(r.name, v)),
                    ),
                    IconButton(
                      icon: const Icon(Icons.delete_outline,
                          color: Colors.redAccent),
                      onPressed:
                          api == null ? null : () => _do(() => api.fwDelete(r.name)),
                    ),
                  ],
                ),
              ),
            const SectionTitle('Zones'),
            for (final z in zones)
              GlassCard(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text((z.o('name') ?? z.name).toUpperCase(),
                        style: const TextStyle(fontWeight: FontWeight.w800)),
                    const SizedBox(height: 6),
                    Wrap(
                      spacing: 6,
                      children: [
                        Pill('in: ${z.o('input') ?? '-'}', Colors.blueGrey),
                        Pill('out: ${z.o('output') ?? '-'}', Colors.blueGrey),
                        Pill('fwd: ${z.o('forward') ?? '-'}', Colors.blueGrey),
                        if (z.o('masq') == '1') const Pill('NAT', Colors.orange),
                      ],
                    ),
                  ],
                ),
              ),
          ],
        ),
      );
    }
    return GlassScaffold(title: 'Firewall', body: body);
  }
}

class _FwAddDialog extends StatefulWidget {
  final bool isRule;
  const _FwAddDialog({required this.isRule});

  @override
  State<_FwAddDialog> createState() => _FwAddDialogState();
}

class _FwAddDialogState extends State<_FwAddDialog> {
  final TextEditingController _name = TextEditingController();
  final TextEditingController _port = TextEditingController();
  final TextEditingController _ip = TextEditingController();
  final TextEditingController _dport = TextEditingController();
  String _proto = 'tcp';
  String _target = 'ACCEPT';

  @override
  void dispose() {
    _name.dispose();
    _port.dispose();
    _ip.dispose();
    _dport.dispose();
    super.dispose();
  }

  Widget _f(TextEditingController c, String label, {bool number = false}) =>
      Padding(
        padding: const EdgeInsets.only(bottom: 10),
        child: TextField(
          controller: c,
          keyboardType: number ? TextInputType.number : null,
          decoration: InputDecoration(labelText: label),
        ),
      );

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      title: Text(widget.isRule ? 'Naya traffic rule' : 'Naya port forward'),
      content: SingleChildScrollView(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            _f(_name, 'Naam'),
            Wrap(
              spacing: 8,
              children: [
                for (final p in ['tcp', 'udp', 'tcp udp'])
                  ChoiceChip(
                    label: Text(p),
                    selected: _proto == p,
                    onSelected: (_) => setState(() => _proto = p),
                  ),
              ],
            ),
            const SizedBox(height: 10),
            _f(_port, widget.isRule ? 'Port (WAN se router par)' : 'External port'),
            if (!widget.isRule) ...[
              _f(_ip, 'Andar ka IP (192.168.1.x)'),
              _f(_dport, 'Andar ka port (khali = same)'),
            ] else
              Wrap(
                spacing: 8,
                children: [
                  for (final a in ['ACCEPT', 'REJECT', 'DROP'])
                    ChoiceChip(
                      label: Text(a),
                      selected: _target == a,
                      onSelected: (_) => setState(() => _target = a),
                    ),
                ],
              ),
          ],
        ),
      ),
      actions: [
        TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Cancel')),
        FilledButton(
          onPressed: () {
            final port = _port.text.trim();
            if (port.isEmpty) {
              showMsg(context, 'Port daalo');
              return;
            }
            if (!widget.isRule && _ip.text.trim().isEmpty) {
              showMsg(context, 'Andar ka IP daalo');
              return;
            }
            final name = _name.text.trim().isEmpty ? 'SharkWRT rule' : _name.text.trim();
            Navigator.pop(context, <String, String>{
              'name': name,
              'proto': _proto,
              'port': port,
              'ip': _ip.text.trim(),
              'dport': _dport.text.trim().isEmpty ? port : _dport.text.trim(),
              'target': _target,
            });
          },
          child: const Text('Stage'),
        ),
      ],
    );
  }
}

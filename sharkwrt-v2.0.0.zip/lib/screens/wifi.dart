import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../core/ui.dart';
import '../data/router_api.dart';
import '../state/app_state.dart';

const List<String> _encs = ['psk2', 'sae-mixed', 'sae', 'psk-mixed', 'none'];

Color _bandColor(String band) {
  if (band == '5G') return const Color(0xFFA78BFA);
  if (band == '6G') return const Color(0xFFFB7185);
  return const Color(0xFF34D399);
}

class WifiTab extends StatefulWidget {
  const WifiTab({super.key});

  @override
  State<WifiTab> createState() => _WifiTabState();
}

class _WifiTabState extends State<WifiTab> {
  WifiData? _data;
  String? _error;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final api = context.read<AppState>().api;
    if (api == null) return;
    try {
      final d = await api.loadWifi();
      if (mounted) {
        setState(() {
          _data = d;
          _error = null;
        });
      }
    } catch (e) {
      if (mounted) setState(() => _error = e.toString());
    }
  }

  Future<void> _run(Future<void> Function() fn) async {
    try {
      await fn();
      if (mounted) showMsg(context, 'Ho gaya. Wi-Fi reload ho raha hai...');
      await Future<void>.delayed(const Duration(seconds: 2));
      await _load();
    } catch (e) {
      if (mounted) showMsg(context, e.toString());
    }
  }

  Future<void> _openSheet(WifiIface? iface) async {
    final data = _data;
    final api = context.read<AppState>().api;
    if (data == null || api == null) return;
    final changed = await showModalBottomSheet<bool>(
      context: context,
      isScrollControlled: true,
      builder: (_) => WifiEditSheet(iface: iface, radios: data.radios, api: api),
    );
    if (changed == true) {
      if (mounted) showMsg(context, 'Save ho gaya. Wi-Fi reload ho raha hai...');
      await Future<void>.delayed(const Duration(seconds: 2));
      await _load();
    }
  }

  @override
  Widget build(BuildContext context) {
    final s = context.watch<AppState>();
    final t = s.theme;
    final api = s.api;
    final d = _data;
    if (d == null) {
      return _error != null
          ? ErrorBox(_error!, onRetry: _load)
          : const Center(child: CircularProgressIndicator());
    }
    return Stack(
      children: [
        RefreshIndicator(
          onRefresh: _load,
          child: ListView(
            padding: const EdgeInsets.fromLTRB(16, 8, 16, 96),
            children: [
              const SectionTitle('Radios'),
              if (d.radios.isEmpty)
                const GlassCard(child: Text('Koi Wi-Fi radio nahi mila')),
              for (final r in d.radios)
                GlassCard(
                  child: Row(
                    children: [
                      Pill(r.band, _bandColor(r.band)),
                      const SizedBox(width: 10),
                      Expanded(
                        child: GestureDetector(
                          onTap: () async {
                            final v = await askText(context, '${r.name} channel',
                                initial: r.channel,
                                hint: 'auto ya number (jaise 6, 36)');
                            if (v != null && v.isNotEmpty && api != null) {
                              await _run(() => api.setRadio(r.name, channel: v));
                            }
                          },
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(r.name,
                                  style: const TextStyle(
                                      fontWeight: FontWeight.w700)),
                              Text(
                                'Channel ${r.channel}${r.htmode.isEmpty ? '' : '  •  ${r.htmode}'}  (tap to change)',
                                style: TextStyle(color: t.sub, fontSize: 12),
                              ),
                            ],
                          ),
                        ),
                      ),
                      Switch(
                        value: !r.disabled,
                        onChanged: api == null
                            ? null
                            : (v) => _run(() => api.setRadio(r.name, disabled: !v)),
                      ),
                    ],
                  ),
                ),
              const SectionTitle('Networks (SSID)'),
              if (d.ifaces.isEmpty)
                const GlassCard(child: Text('Koi SSID nahi hai. + dabake banao.')),
              for (final i in d.ifaces)
                GlassCard(
                  onTap: i.mode == 'ap' ? () => _openSheet(i) : null,
                  child: Row(
                    children: [
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              i.ssid.isEmpty ? '(no name)' : i.ssid,
                              style: const TextStyle(
                                  fontSize: 16, fontWeight: FontWeight.w700),
                            ),
                            const SizedBox(height: 6),
                            Wrap(
                              spacing: 6,
                              runSpacing: 4,
                              children: [
                                Pill(d.bandOf(i.device),
                                    _bandColor(d.bandOf(i.device))),
                                Pill(i.encryption, Colors.blueGrey),
                                if (i.mode != 'ap') Pill(i.mode, Colors.orange),
                              ],
                            ),
                          ],
                        ),
                      ),
                      if (i.mode == 'ap')
                        Switch(
                          value: !i.disabled,
                          onChanged: api == null
                              ? null
                              : (v) => _run(() => api.updateIface(
                                    i.section,
                                    ssid: i.ssid,
                                    encryption: i.encryption,
                                    key: '',
                                    disabled: !v,
                                  )),
                        ),
                    ],
                  ),
                ),
            ],
          ),
        ),
        Positioned(
          right: 16,
          bottom: 16,
          child: FloatingActionButton(
            onPressed: () => _openSheet(null),
            child: const Icon(Icons.add),
          ),
        ),
      ],
    );
  }
}

class WifiEditSheet extends StatefulWidget {
  final WifiIface? iface;
  final List<RadioInfo> radios;
  final RouterApi api;
  const WifiEditSheet({
    super.key,
    required this.iface,
    required this.radios,
    required this.api,
  });

  @override
  State<WifiEditSheet> createState() => _WifiEditSheetState();
}

class _WifiEditSheetState extends State<WifiEditSheet> {
  late final TextEditingController _ssid;
  final TextEditingController _key = TextEditingController();
  late String _enc;
  late String _radio;
  bool _hide = true;
  bool _busy = false;

  bool get _isNew => widget.iface == null;

  @override
  void initState() {
    super.initState();
    final i = widget.iface;
    _ssid = TextEditingController(text: i?.ssid ?? '');
    _enc = i?.encryption ?? 'psk2';
    if (!_encs.contains(_enc)) _enc = 'psk2';
    _radio = widget.radios.isNotEmpty ? widget.radios.first.name : '';
  }

  @override
  void dispose() {
    _ssid.dispose();
    _key.dispose();
    super.dispose();
  }

  Future<void> _save() async {
    final ssid = _ssid.text.trim();
    final key = _key.text;
    if (ssid.isEmpty || ssid.length > 32) {
      showMsg(context, 'SSID 1 se 32 character ka hona chahiye');
      return;
    }
    if (_enc != 'none') {
      if ((_isNew || key.isNotEmpty) && (key.length < 8 || key.length > 63)) {
        showMsg(context, 'Password 8 se 63 character ka hona chahiye');
        return;
      }
    }
    if (_isNew && _radio.isEmpty) {
      showMsg(context, 'Radio nahi mila');
      return;
    }
    setState(() => _busy = true);
    final nav = Navigator.of(context);
    try {
      if (_isNew) {
        await widget.api.addIface(
            radio: _radio, ssid: ssid, encryption: _enc, key: key);
      } else {
        await widget.api.updateIface(
          widget.iface!.section,
          ssid: ssid,
          encryption: _enc,
          key: key,
          disabled: widget.iface!.disabled,
        );
      }
      nav.pop(true);
    } catch (e) {
      if (mounted) {
        setState(() => _busy = false);
        showMsg(context, e.toString());
      }
    }
  }

  Future<void> _delete() async {
    final ok = await confirmDialog(context, 'SSID delete?',
        '"${widget.iface!.ssid}" hamesha ke liye hat jayega.',
        ok: 'Delete');
    if (!ok || !mounted) return;
    setState(() => _busy = true);
    final nav = Navigator.of(context);
    try {
      await widget.api.deleteIface(widget.iface!.section);
      nav.pop(true);
    } catch (e) {
      if (mounted) {
        setState(() => _busy = false);
        showMsg(context, e.toString());
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    final bottom = MediaQuery.of(context).viewInsets.bottom;
    return SingleChildScrollView(
      padding: EdgeInsets.fromLTRB(20, 20, 20, 20 + bottom),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(_isNew ? 'Naya SSID' : 'SSID edit',
              style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w800)),
          const SizedBox(height: 16),
          if (_isNew) ...[
            const Text('Band / radio'),
            const SizedBox(height: 6),
            Wrap(
              spacing: 8,
              children: [
                for (final r in widget.radios)
                  ChoiceChip(
                    label: Text('${r.band} (${r.name})'),
                    selected: _radio == r.name,
                    onSelected: (_) => setState(() => _radio = r.name),
                  ),
              ],
            ),
            const SizedBox(height: 14),
          ],
          TextField(
            controller: _ssid,
            decoration: const InputDecoration(labelText: 'SSID (naam)'),
          ),
          const SizedBox(height: 14),
          const Text('Security'),
          const SizedBox(height: 6),
          Wrap(
            spacing: 8,
            children: [
              for (final e in _encs)
                ChoiceChip(
                  label: Text(e),
                  selected: _enc == e,
                  onSelected: (_) => setState(() => _enc = e),
                ),
            ],
          ),
          if (_enc != 'none') ...[
            const SizedBox(height: 14),
            TextField(
              controller: _key,
              obscureText: _hide,
              decoration: InputDecoration(
                labelText: _isNew ? 'Password' : 'Naya password (khali = wahi rahe)',
                suffixIcon: IconButton(
                  icon: Icon(_hide ? Icons.visibility : Icons.visibility_off),
                  onPressed: () => setState(() => _hide = !_hide),
                ),
              ),
            ),
          ],
          const SizedBox(height: 20),
          Row(
            children: [
              if (!_isNew)
                TextButton.icon(
                  onPressed: _busy ? null : _delete,
                  icon: const Icon(Icons.delete_outline, color: Colors.redAccent),
                  label: const Text('Delete',
                      style: TextStyle(color: Colors.redAccent)),
                ),
              const Spacer(),
              TextButton(
                onPressed: _busy ? null : () => Navigator.pop(context),
                child: const Text('Cancel'),
              ),
              const SizedBox(width: 8),
              FilledButton(
                onPressed: _busy ? null : _save,
                child: Text(_busy ? '...' : 'Save'),
              ),
            ],
          ),
        ],
      ),
    );
  }
}

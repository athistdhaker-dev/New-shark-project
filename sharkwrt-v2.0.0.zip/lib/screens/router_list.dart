import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../core/ui.dart';
import '../data/models.dart';
import '../state/app_state.dart';
import 'settings.dart';
import 'shell.dart';

class RouterListScreen extends StatelessWidget {
  const RouterListScreen({super.key});

  Future<void> _open(BuildContext context, RouterProfile p) async {
    final s = context.read<AppState>();
    final nav = Navigator.of(context);
    final messenger = ScaffoldMessenger.of(context);
    showDialog<void>(
      context: context,
      barrierDismissible: false,
      builder: (_) => const Center(child: CircularProgressIndicator()),
    );
    final err = await s.connect(p);
    nav.pop();
    if (err != null) {
      messenger
        ..hideCurrentSnackBar()
        ..showSnackBar(SnackBar(content: Text(err)));
      return;
    }
    await nav.push(MaterialPageRoute<void>(builder: (_) => const ShellScreen()));
    s.disconnect();
  }

  @override
  Widget build(BuildContext context) {
    final s = context.watch<AppState>();
    final t = s.theme;
    return GlassScaffold(
      title: 'SharkWRT',
      actions: [
        IconButton(
          icon: const Icon(Icons.palette_outlined),
          onPressed: () => Navigator.push(
            context,
            MaterialPageRoute<void>(builder: (_) => const SettingsScreen()),
          ),
        ),
      ],
      fab: FloatingActionButton.extended(
        onPressed: () => Navigator.push(
          context,
          MaterialPageRoute<void>(builder: (_) => const RouterFormScreen()),
        ),
        icon: const Icon(Icons.add),
        label: const Text('Router'),
      ),
      body: s.profiles.isEmpty
          ? Center(
              child: Padding(
                padding: const EdgeInsets.all(32),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Icon(Icons.router_outlined, size: 64, color: t.sub),
                    const SizedBox(height: 16),
                    const Text(
                      'Koi router nahi jura',
                      style: TextStyle(fontSize: 18, fontWeight: FontWeight.w700),
                    ),
                    const SizedBox(height: 8),
                    Text(
                      'Neeche "+ Router" dabao. OpenWrt par SSH chalu hona chahiye (default me hota hai).',
                      textAlign: TextAlign.center,
                      style: TextStyle(color: t.sub),
                    ),
                  ],
                ),
              ),
            )
          : ListView(
              padding: const EdgeInsets.fromLTRB(16, 8, 16, 96),
              children: [
                for (final p in s.profiles)
                  GlassCard(
                    onTap: () => _open(context, p),
                    child: Row(
                      children: [
                        Icon(Icons.router, color: s.accent, size: 30),
                        const SizedBox(width: 14),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                p.name,
                                style: const TextStyle(
                                    fontSize: 16, fontWeight: FontWeight.w700),
                              ),
                              const SizedBox(height: 2),
                              Text(
                                '${p.user}@${p.host}:${p.port}',
                                style: TextStyle(color: t.sub, fontSize: 13),
                              ),
                            ],
                          ),
                        ),
                        PopupMenuButton<String>(
                          onSelected: (v) async {
                            if (v == 'edit') {
                              Navigator.push(
                                context,
                                MaterialPageRoute<void>(
                                    builder: (_) => RouterFormScreen(profile: p)),
                              );
                            } else if (v == 'hostkey') {
                              await s.resetHostKey(p.id);
                              if (context.mounted) {
                                showMsg(context, 'Host key reset ho gaya');
                              }
                            } else if (v == 'delete') {
                              final ok = await confirmDialog(
                                  context, 'Delete?', '${p.name} hata dein?');
                              if (ok) await s.deleteProfile(p.id);
                            }
                          },
                          itemBuilder: (_) => const [
                            PopupMenuItem(value: 'edit', child: Text('Edit')),
                            PopupMenuItem(
                                value: 'hostkey', child: Text('Host key reset')),
                            PopupMenuItem(value: 'delete', child: Text('Delete')),
                          ],
                        ),
                      ],
                    ),
                  ),
              ],
            ),
    );
  }
}

class RouterFormScreen extends StatefulWidget {
  final RouterProfile? profile;
  const RouterFormScreen({super.key, this.profile});

  @override
  State<RouterFormScreen> createState() => _RouterFormScreenState();
}

class _RouterFormScreenState extends State<RouterFormScreen> {
  late final TextEditingController _name;
  late final TextEditingController _host;
  late final TextEditingController _port;
  late final TextEditingController _user;
  final TextEditingController _pass = TextEditingController();
  final TextEditingController _key = TextEditingController();
  bool _useKey = false;
  bool _hide = true;
  bool _saving = false;

  @override
  void initState() {
    super.initState();
    final p = widget.profile;
    _name = TextEditingController(text: p?.name ?? 'My Router');
    _host = TextEditingController(text: p?.host ?? '192.168.1.1');
    _port = TextEditingController(text: '${p?.port ?? 22}');
    _user = TextEditingController(text: p?.user ?? 'root');
    _useKey = p?.useKey ?? false;
  }

  @override
  void dispose() {
    _name.dispose();
    _host.dispose();
    _port.dispose();
    _user.dispose();
    _pass.dispose();
    _key.dispose();
    super.dispose();
  }

  Future<void> _save() async {
    final host = _host.text.trim();
    final port = int.tryParse(_port.text.trim()) ?? 22;
    if (host.isEmpty || _user.text.trim().isEmpty) {
      showMsg(context, 'Host aur username zaroori hain');
      return;
    }
    if (!_useKey && widget.profile == null && _pass.text.isEmpty) {
      showMsg(context, 'Password daalo');
      return;
    }
    if (_useKey && widget.profile == null && _key.text.trim().isEmpty) {
      showMsg(context, 'Private key paste karo');
      return;
    }
    setState(() => _saving = true);
    final s = context.read<AppState>();
    final nav = Navigator.of(context);
    final p = RouterProfile(
      id: widget.profile?.id ?? DateTime.now().microsecondsSinceEpoch.toString(),
      name: _name.text.trim().isEmpty ? host : _name.text.trim(),
      host: host,
      port: port,
      user: _user.text.trim(),
      useKey: _useKey,
    );
    try {
      await s.saveProfile(
        p,
        password: _pass.text.isNotEmpty ? _pass.text : null,
        key: _key.text.trim().isNotEmpty ? _key.text.trim() : null,
      );
      nav.pop();
    } catch (e) {
      if (mounted) {
        setState(() => _saving = false);
        showMsg(context, 'Save nahi hua: $e');
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    final editing = widget.profile != null;
    return GlassScaffold(
      title: editing ? 'Edit router' : 'Router jodo',
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          TextField(
            controller: _name,
            decoration: const InputDecoration(labelText: 'Naam'),
          ),
          const SizedBox(height: 12),
          TextField(
            controller: _host,
            keyboardType: TextInputType.url,
            decoration: const InputDecoration(labelText: 'IP / Host'),
          ),
          const SizedBox(height: 12),
          Row(
            children: [
              Expanded(
                child: TextField(
                  controller: _user,
                  decoration: const InputDecoration(labelText: 'Username'),
                ),
              ),
              const SizedBox(width: 12),
              SizedBox(
                width: 100,
                child: TextField(
                  controller: _port,
                  keyboardType: TextInputType.number,
                  decoration: const InputDecoration(labelText: 'Port'),
                ),
              ),
            ],
          ),
          const SizedBox(height: 16),
          SegmentedButton<bool>(
            segments: const [
              ButtonSegment<bool>(value: false, label: Text('Password')),
              ButtonSegment<bool>(value: true, label: Text('SSH Key')),
            ],
            selected: {_useKey},
            onSelectionChanged: (v) => setState(() => _useKey = v.first),
          ),
          const SizedBox(height: 12),
          if (!_useKey)
            TextField(
              controller: _pass,
              obscureText: _hide,
              decoration: InputDecoration(
                labelText: editing ? 'Password (khali = purana)' : 'Password',
                suffixIcon: IconButton(
                  icon: Icon(_hide ? Icons.visibility : Icons.visibility_off),
                  onPressed: () => setState(() => _hide = !_hide),
                ),
              ),
            )
          else
            TextField(
              controller: _key,
              minLines: 5,
              maxLines: 8,
              decoration: InputDecoration(
                labelText: editing
                    ? 'Private key PEM (khali = purani)'
                    : 'Private key (PEM / OpenSSH)',
              ),
            ),
          const SizedBox(height: 8),
          Text(
            'Password aur key phone ke encrypted Keystore me save hote hain.',
            style: TextStyle(color: context.watch<AppState>().theme.sub, fontSize: 12),
          ),
          const SizedBox(height: 20),
          FilledButton(
            onPressed: _saving ? null : _save,
            child: Text(_saving ? 'Saving...' : 'Save'),
          ),
        ],
      ),
    );
  }
}

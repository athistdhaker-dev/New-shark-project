import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../core/forms.dart';
import '../core/ui.dart';
import '../data/router_api.dart';
import '../state/app_state.dart';

class NetworkTab extends StatefulWidget {
  const NetworkTab({super.key});

  @override
  State<NetworkTab> createState() => _NetworkTabState();
}

class _NetworkTabState extends State<NetworkTab> {
  NetworkData? _data;
  String? _error;

  @override
  void initState() {
    super.initState();
    _load();
  }

  RouterApi? get _api => context.read<AppState>().api;

  Future<void> _load() async {
    final api = _api;
    if (api == null) return;
    try {
      final d = await api.loadNetwork();
      if (mounted) {
        setState(() {
          _data = d;
          _error = null;
        });
      }
    } catch (e) {
      if (mounted) setState(() => _error = e.toString());
    }
  }

  Future<void> _do(Future<void> Function() fn, String done) async {
    try {
      await fn();
      if (mounted) showMsg(context, done);
      await Future<void>.delayed(const Duration(seconds: 1));
      await _load();
    } catch (e) {
      if (mounted) showMsg(context, e.toString());
    }
  }

  Widget _kv(String k, String v) {
    final t = context.watch<AppState>().theme;
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 3),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          SizedBox(width: 92, child: Text(k, style: TextStyle(color: t.sub))),
          Expanded(child: Text(v.isEmpty ? '-' : v)),
        ],
      ),
    );
  }

  Future<void> _editLan() async {
    final api = _api;
    final lan = _data?.network['lan'];
    if (api == null) return;
    final ok = await confirmDialog(
      context,
      'LAN IP badlein?',
      'IP badalne par ye connection toot jayega aur naye IP se dobara jodna padega. Galat IP se router tak pahunch band ho sakti hai.',
      ok: 'Aage badho',
    );
    if (!ok || !mounted) return;
    final v = await askForm(
      context,
      'LAN IP',
      [
        FField('IP address', lan?.o('ipaddr') ?? '192.168.1.1'),
        FField('Netmask (CIDR ho to khali)', lan?.o('netmask') ?? ''),
      ],
    );
    if (v == null || v[0].isEmpty) return;
    await _do(() => api.setLan(ipaddr: v[0], netmask: v[1]),
        'Save ho gaya. Network reload ho raha hai...');
  }

  Future<void> _editDhcp() async {
    final api = _api;
    final d = _data?.dhcp['lan'];
    if (api == null) return;
    final v = await askForm(context, 'DHCP server', [
      FField('Start (host number)', d?.o('start') ?? '100', false,
          TextInputType.number),
      FField('Limit (kitne IP)', d?.o('limit') ?? '150', false,
          TextInputType.number),
      FField('Lease time', d?.o('leasetime') ?? '12h'),
    ]);
    if (v == null) return;
    await _do(() => api.setDhcp(start: v[0], limit: v[1], leasetime: v[2]),
        'DHCP update ho gaya');
  }

  Future<void> _editWan() async {
    final api = _api;
    final wan = _data?.network['wan'];
    if (api == null) return;
    if (wan == null) {
      showMsg(context, 'WAN interface nahi mila');
      return;
    }
    final r = await showDialog<Map<String, String>>(
      context: context,
      builder: (_) => _WanDialog(
        proto: wan.o('proto') ?? 'dhcp',
        username: wan.o('username') ?? '',
        ipaddr: wan.o('ipaddr') ?? '',
        netmask: wan.o('netmask') ?? '',
        gateway: wan.o('gateway') ?? '',
        dns: wan.o('dns') ?? '',
        mac: wan.o('macaddr') ?? '',
      ),
    );
    if (r == null) return;
    await _do(
      () => api.setWan(
        proto: r['proto'] ?? 'dhcp',
        username: r['username'] ?? '',
        password: r['password'] ?? '',
        ipaddr: r['ipaddr'] ?? '',
        netmask: r['netmask'] ?? '',
        gateway: r['gateway'] ?? '',
        dns: r['dns'] ?? '',
        macaddr: r['mac'] ?? '',
      ),
      'WAN save ho gaya. Network reload ho raha hai...',
    );
  }

  Future<void> _addLease() async {
    final api = _api;
    if (api == null) return;
    final v = await askForm(context, 'IP reservation', [
      const FField('Naam (optional)'),
      const FField('MAC (aa:bb:cc:dd:ee:ff)'),
      const FField('IP (192.168.1.50)', '', false, TextInputType.number),
    ]);
    if (v == null) return;
    await _do(() => api.addStaticLease(v[0], v[1], v[2]), 'Reservation ban gayi');
  }

  Future<void> _ping() async {
    final api = _api;
    if (api == null) return;
    showDialog<void>(
      context: context,
      barrierDismissible: false,
      builder: (_) => const Center(child: CircularProgressIndicator()),
    );
    String out;
    try {
      out = await api.pingTest();
    } catch (e) {
      out = e.toString();
    }
    if (!mounted) return;
    Navigator.of(context).pop();
    showDialog<void>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Internet test'),
        content: SingleChildScrollView(
          child: Text(out.trim(),
              style: const TextStyle(fontFamily: 'monospace', fontSize: 12)),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('OK')),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final d = _data;
    if (d == null) {
      return _error != null
          ? ErrorBox(_error!, onRetry: _load)
          : const Center(child: CircularProgressIndicator());
    }
    final lan = d.network['lan'];
    final wan = d.network['wan'];
    final dhcp = d.dhcp['lan'];
    final leases = d.dhcp.ofType('host').toList();
    return RefreshIndicator(
      onRefresh: _load,
      child: ListView(
        padding: const EdgeInsets.fromLTRB(16, 8, 16, 24),
        children: [
          SectionTitle('LAN',
              trailing: TextButton(onPressed: _editLan, child: const Text('Edit'))),
          GlassCard(
            child: Column(
              children: [
                _kv('IP', lan?.o('ipaddr') ?? ''),
                _kv('Netmask', lan?.o('netmask') ?? ''),
              ],
            ),
          ),
          SectionTitle('DHCP server',
              trailing:
                  TextButton(onPressed: _editDhcp, child: const Text('Edit'))),
          GlassCard(
            child: Column(
              children: [
                _kv('Start', dhcp?.o('start') ?? ''),
                _kv('Limit', dhcp?.o('limit') ?? ''),
                _kv('Lease time', dhcp?.o('leasetime') ?? ''),
              ],
            ),
          ),
          SectionTitle('WAN',
              trailing: TextButton(onPressed: _editWan, child: const Text('Edit'))),
          GlassCard(
            child: Column(
              children: [
                _kv('Protocol', wan?.o('proto') ?? ''),
                if ((wan?.o('proto') ?? '') == 'pppoe')
                  _kv('Username', wan?.o('username') ?? ''),
                if ((wan?.o('proto') ?? '') == 'static') ...[
                  _kv('IP', wan?.o('ipaddr') ?? ''),
                  _kv('Gateway', wan?.o('gateway') ?? ''),
                ],
                _kv('DNS', wan?.o('dns') ?? ''),
                _kv('MAC clone', wan?.o('macaddr') ?? ''),
              ],
            ),
          ),
          SectionTitle('IP reservations',
              trailing: TextButton(onPressed: _addLease, child: const Text('+ Add'))),
          if (leases.isEmpty) const GlassCard(child: Text('Koi reservation nahi')),
          for (final l in leases)
            GlassCard(
              child: Row(
                children: [
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          (l.o('name') ?? '').isEmpty ? '(no name)' : l.o('name')!,
                          style: const TextStyle(fontWeight: FontWeight.w700),
                        ),
                        Text('${l.o('ip') ?? '-'}  •  ${l.o('mac') ?? '-'}',
                            style: const TextStyle(fontSize: 12)),
                      ],
                    ),
                  ),
                  IconButton(
                    icon: const Icon(Icons.delete_outline, color: Colors.redAccent),
                    onPressed: () async {
                      final api = _api;
                      if (api == null) return;
                      final ok = await confirmDialog(
                          context, 'Delete?', 'Ye reservation hata dein?',
                          ok: 'Delete');
                      if (ok) {
                        await _do(() => api.deleteStaticLease(l.name),
                            'Reservation hat gayi');
                      }
                    },
                  ),
                ],
              ),
            ),
          const SectionTitle('Tools'),
          OutlinedButton.icon(
            onPressed: _ping,
            icon: const Icon(Icons.network_check),
            label: const Text('Internet test (ping)'),
          ),
        ],
      ),
    );
  }
}

class _WanDialog extends StatefulWidget {
  final String proto;
  final String username;
  final String ipaddr;
  final String netmask;
  final String gateway;
  final String dns;
  final String mac;
  const _WanDialog({
    required this.proto,
    required this.username,
    required this.ipaddr,
    required this.netmask,
    required this.gateway,
    required this.dns,
    required this.mac,
  });

  @override
  State<_WanDialog> createState() => _WanDialogState();
}

class _WanDialogState extends State<_WanDialog> {
  late String _proto;
  late final TextEditingController _user;
  final TextEditingController _pass = TextEditingController();
  late final TextEditingController _ip;
  late final TextEditingController _mask;
  late final TextEditingController _gw;
  late final TextEditingController _dns;
  late final TextEditingController _mac;

  @override
  void initState() {
    super.initState();
    _proto = ['dhcp', 'static', 'pppoe'].contains(widget.proto)
        ? widget.proto
        : 'dhcp';
    _user = TextEditingController(text: widget.username);
    _ip = TextEditingController(text: widget.ipaddr);
    _mask = TextEditingController(text: widget.netmask);
    _gw = TextEditingController(text: widget.gateway);
    _dns = TextEditingController(text: widget.dns);
    _mac = TextEditingController(text: widget.mac);
  }

  @override
  void dispose() {
    _user.dispose();
    _pass.dispose();
    _ip.dispose();
    _mask.dispose();
    _gw.dispose();
    _dns.dispose();
    _mac.dispose();
    super.dispose();
  }

  Widget _f(TextEditingController c, String label, {bool obscure = false}) =>
      Padding(
        padding: const EdgeInsets.only(bottom: 10),
        child: TextField(
          controller: c,
          obscureText: obscure,
          decoration: InputDecoration(labelText: label),
        ),
      );

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      title: const Text('WAN settings'),
      content: SingleChildScrollView(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Wrap(
              spacing: 8,
              children: [
                for (final p in ['dhcp', 'static', 'pppoe'])
                  ChoiceChip(
                    label: Text(p),
                    selected: _proto == p,
                    onSelected: (_) => setState(() => _proto = p),
                  ),
              ],
            ),
            const SizedBox(height: 12),
            if (_proto == 'pppoe') ...[
              _f(_user, 'PPPoE username'),
              _f(_pass, 'PPPoE password (khali = purana)', obscure: true),
            ],
            if (_proto == 'static') ...[
              _f(_ip, 'IP address'),
              _f(_mask, 'Netmask'),
              _f(_gw, 'Gateway'),
            ],
            _f(_dns, 'DNS (space ya comma se alag; khali = ISP)'),
            _f(_mac, 'MAC clone (khali = default)'),
          ],
        ),
      ),
      actions: [
        TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Cancel')),
        FilledButton(
          onPressed: () => Navigator.pop(context, <String, String>{
            'proto': _proto,
            'username': _user.text.trim(),
            'password': _pass.text,
            'ipaddr': _ip.text.trim(),
            'netmask': _mask.text.trim(),
            'gateway': _gw.text.trim(),
            'dns': _dns.text.trim(),
            'mac': _mac.text.trim(),
          }),
          child: const Text('Save'),
        ),
      ],
    );
  }
}

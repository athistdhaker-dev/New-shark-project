import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../core/ui.dart';
import '../state/app_state.dart';
import 'firewall.dart';
import 'settings.dart';
import 'system.dart';
import 'terminal.dart';

class MoreTab extends StatelessWidget {
  const MoreTab({super.key});

  Widget _item(BuildContext context, IconData icon, String title, String sub,
      Widget Function() page) {
    final t = context.watch<AppState>().theme;
    return GlassCard(
      onTap: () => Navigator.push(
        context,
        MaterialPageRoute<void>(builder: (_) => page()),
      ),
      child: Row(
        children: [
          Icon(icon, color: context.watch<AppState>().accent),
          const SizedBox(width: 14),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(title,
                    style: const TextStyle(
                        fontSize: 15, fontWeight: FontWeight.w700)),
                Text(sub, style: TextStyle(color: t.sub, fontSize: 12)),
              ],
            ),
          ),
          Icon(Icons.chevron_right, color: t.sub),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        _item(context, Icons.shield_outlined, 'Firewall',
            'Port forward, rules, Apply / Discard', () => const FirewallScreen()),
        _item(context, Icons.terminal, 'Terminal',
            'Router par command chalao', () => const TerminalScreen()),
        _item(context, Icons.miscellaneous_services_outlined, 'Services',
            'Start / stop / enable', () => const ServicesScreen()),
        _item(context, Icons.article_outlined, 'Logs', 'Live system log',
            () => const LogsScreen()),
        _item(context, Icons.settings_outlined, 'System',
            'Hostname, reboot', () => const SystemScreen()),
        _item(context, Icons.palette_outlined, 'App settings',
            'Theme, accent, blur', () => const SettingsScreen()),
        GlassCard(
          onTap: () => Navigator.of(context).pop(),
          child: const Row(
            children: [
              Icon(Icons.swap_horiz),
              SizedBox(width: 14),
              Text('Router badlo',
                  style: TextStyle(fontSize: 15, fontWeight: FontWeight.w700)),
            ],
          ),
        ),
      ],
    );
  }
}

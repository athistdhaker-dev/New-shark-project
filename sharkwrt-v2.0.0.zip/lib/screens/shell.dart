import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../core/ui.dart';
import '../state/app_state.dart';
import 'clients.dart';
import 'dashboard.dart';
import 'more.dart';
import 'network.dart';
import 'wifi.dart';

class ShellScreen extends StatefulWidget {
  const ShellScreen({super.key});

  @override
  State<ShellScreen> createState() => _ShellScreenState();
}

class _ShellScreenState extends State<ShellScreen> {
  int _index = 0;
  final Set<int> _visited = {0};

  Widget _tab(int i) {
    switch (i) {
      case 0:
        return const DashboardTab();
      case 1:
        return const WifiTab();
      case 2:
        return const ClientsTab();
      case 3:
        return const NetworkTab();
      default:
        return const MoreTab();
    }
  }

  @override
  Widget build(BuildContext context) {
    final s = context.watch<AppState>();
    final title = s.active?.name ?? 'Router';
    return GlassBackground(
      child: Scaffold(
        backgroundColor: Colors.transparent,
        appBar: AppBar(title: Text(title)),
        body: SafeArea(
          top: false,
          child: IndexedStack(
            index: _index,
            children: [
              for (var i = 0; i < 5; i++)
                _visited.contains(i) ? _tab(i) : const SizedBox.shrink(),
            ],
          ),
        ),
        bottomNavigationBar: NavigationBar(
          selectedIndex: _index,
          onDestinationSelected: (i) => setState(() {
            _index = i;
            _visited.add(i);
          }),
          destinations: const [
            NavigationDestination(
                icon: Icon(Icons.speed_outlined),
                selectedIcon: Icon(Icons.speed),
                label: 'Home'),
            NavigationDestination(
                icon: Icon(Icons.wifi_outlined),
                selectedIcon: Icon(Icons.wifi),
                label: 'Wi-Fi'),
            NavigationDestination(
                icon: Icon(Icons.devices_outlined),
                selectedIcon: Icon(Icons.devices),
                label: 'Devices'),
            NavigationDestination(
                icon: Icon(Icons.lan_outlined),
                selectedIcon: Icon(Icons.lan),
                label: 'Network'),
            NavigationDestination(
                icon: Icon(Icons.grid_view_outlined),
                selectedIcon: Icon(Icons.grid_view),
                label: 'More'),
          ],
        ),
      ),
    );
  }
}

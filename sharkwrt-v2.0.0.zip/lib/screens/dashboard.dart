import 'dart:async';
import 'dart:math' as math;

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../core/ui.dart';
import '../data/router_api.dart';
import '../state/app_state.dart';

const int _cap = 40;

class DashboardTab extends StatefulWidget {
  const DashboardTab({super.key});

  @override
  State<DashboardTab> createState() => _DashboardTabState();
}

class _DashboardTabState extends State<DashboardTab> {
  Timer? _timer;
  bool _busy = false;
  String? _error;
  Stats? _stats;
  Stats? _prev;
  RouterInfo? _info;
  double _down = 0;
  double _up = 0;
  int _tick = 0;
  final List<double> _dl = [];
  final List<double> _ul = [];

  @override
  void initState() {
    super.initState();
    _poll();
    _timer = Timer.periodic(const Duration(seconds: 3), (_) => _poll());
  }

  @override
  void dispose() {
    _timer?.cancel();
    super.dispose();
  }

  String _wanDevice(Stats st, String wanDev) {
    if (wanDev.isNotEmpty && st.net.containsKey(wanDev)) return wanDev;
    if (st.net.containsKey('eth1')) return 'eth1';
    return 'eth0';
  }

  Future<void> _poll() async {
    if (_busy) return;
    final api = context.read<AppState>().api;
    if (api == null) return;
    _busy = true;
    try {
      if (_info == null || _tick % 10 == 0) {
        final i = await api.loadInfo();
        if (mounted) setState(() => _info = i);
      }
      _tick++;
      final st = await api.loadStats();
      final dev = _wanDevice(st, api.wanDev);
      final cur = st.net[dev];
      final prev = _prev;
      if (prev != null && cur != null) {
        final p = prev.net[dev];
        final dt = st.at.difference(prev.at).inMilliseconds / 1000.0;
        if (p != null && dt > 0) {
          _down = math.max(0, (cur[0] - p[0]) / dt);
          _up = math.max(0, (cur[1] - p[1]) / dt);
          _dl.add(_down);
          _ul.add(_up);
          if (_dl.length > _cap) _dl.removeAt(0);
          if (_ul.length > _cap) _ul.removeAt(0);
        }
      }
      _prev = st;
      if (mounted) {
        setState(() {
          _stats = st;
          _error = null;
        });
      }
    } catch (e) {
      if (mounted) setState(() => _error = e.toString());
    } finally {
      _busy = false;
    }
  }

  Widget _bar(String label, double frac, String text, Color color) {
    final t = context.watch<AppState>().theme;
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 6),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Expanded(
                  child: Text(label,
                      style: const TextStyle(fontWeight: FontWeight.w600))),
              Text(text, style: TextStyle(color: t.sub, fontSize: 13)),
            ],
          ),
          const SizedBox(height: 6),
          ClipRRect(
            borderRadius: BorderRadius.circular(6),
            child: LinearProgressIndicator(
              value: frac.clamp(0.0, 1.0).toDouble(),
              minHeight: 8,
              color: color,
              backgroundColor: color.withAlpha(40),
            ),
          ),
        ],
      ),
    );
  }

  Future<void> _action(Future<void> Function() fn, String done) async {
    try {
      await fn();
      if (mounted) showMsg(context, done);
    } catch (e) {
      if (mounted) showMsg(context, e.toString());
    }
  }

  @override
  Widget build(BuildContext context) {
    final s = context.watch<AppState>();
    final t = s.theme;
    final api = s.api;
    final st = _stats;
    final info = _info ?? s.info;
    if (st == null) {
      return _error != null
          ? ErrorBox(_error!, onRetry: _poll)
          : const Center(child: CircularProgressIndicator());
    }
    final memFrac = st.memTotal > 0 ? st.memUsed / st.memTotal : 0.0;
    final flashFrac = st.flashTotal > 0 ? st.flashUsed / st.flashTotal : 0.0;
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        if (_error != null)
          GlassCard(
            child: Row(
              children: [
                const Icon(Icons.wifi_off, color: Colors.orangeAccent),
                const SizedBox(width: 10),
                Expanded(child: Text(_error!)),
              ],
            ),
          ),
        GlassCard(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                info.model.isEmpty ? 'OpenWrt router' : info.model,
                style: const TextStyle(fontSize: 17, fontWeight: FontWeight.w800),
              ),
              const SizedBox(height: 4),
              Text(
                [
                  if (info.release.isNotEmpty) info.release,
                  'Uptime ${fmtUptime(st.uptime)}',
                ].join('  •  '),
                style: TextStyle(color: t.sub, fontSize: 13),
              ),
            ],
          ),
        ),
        GlassCard(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text('DOWNLOAD',
                            style: TextStyle(
                                color: t.sub, fontSize: 11, letterSpacing: 1)),
                        const SizedBox(height: 2),
                        Text(fmtRate(_down),
                            style: TextStyle(
                                fontSize: 22,
                                fontWeight: FontWeight.w800,
                                color: s.accent)),
                      ],
                    ),
                  ),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text('UPLOAD',
                            style: TextStyle(
                                color: t.sub, fontSize: 11, letterSpacing: 1)),
                        const SizedBox(height: 2),
                        Text(fmtRate(_up),
                            style: const TextStyle(
                                fontSize: 22,
                                fontWeight: FontWeight.w800,
                                color: Color(0xFFFBBF24))),
                      ],
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 12),
              SizedBox(
                height: 70,
                width: double.infinity,
                child: CustomPaint(
                  painter: SparkPainter(
                      _dl, _ul, s.accent, const Color(0xFFFBBF24)),
                ),
              ),
            ],
          ),
        ),
        GlassCard(
          child: Column(
            children: [
              _bar('CPU', st.cpu / 100, '${st.cpu.toStringAsFixed(0)}%  (load ${st.load.toStringAsFixed(2)})', s.accent),
              _bar('RAM', memFrac.toDouble(), '${fmtKb(st.memUsed)} / ${fmtKb(st.memTotal)}', const Color(0xFF34D399)),
              _bar('Flash', flashFrac.toDouble(), '${fmtKb(st.flashUsed)} / ${fmtKb(st.flashTotal)}', const Color(0xFFA78BFA)),
            ],
          ),
        ),
        GlassCard(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  const Text('WAN',
                      style: TextStyle(fontWeight: FontWeight.w800)),
                  const SizedBox(width: 10),
                  Pill(info.wanUp ? 'UP' : 'DOWN',
                      info.wanUp ? Colors.greenAccent : Colors.redAccent),
                ],
              ),
              const SizedBox(height: 8),
              _kv('IP', info.wanIp.isEmpty ? '-' : info.wanIp),
              _kv('Protocol', info.wanProto.isEmpty ? '-' : info.wanProto),
              _kv('DNS', info.dns.isEmpty ? '-' : info.dns),
            ],
          ),
        ),
        const SectionTitle('Quick actions'),
        Row(
          children: [
            Expanded(
              child: OutlinedButton.icon(
                onPressed: api == null
                    ? null
                    : () => _action(api.restartWifi, 'Wi-Fi restart ho raha hai'),
                icon: const Icon(Icons.wifi),
                label: const Text('Wi-Fi restart'),
              ),
            ),
            const SizedBox(width: 10),
            Expanded(
              child: OutlinedButton.icon(
                onPressed: api == null
                    ? null
                    : () async {
                        final ok = await confirmDialog(
                            context,
                            'Network restart?',
                            'Kuch second ke liye internet jayega.');
                        if (ok) {
                          await _action(
                              api.restartNetwork, 'Network restart ho raha hai');
                        }
                      },
                icon: const Icon(Icons.refresh),
                label: const Text('Network'),
              ),
            ),
          ],
        ),
        const SizedBox(height: 12),
        HoldButton(
          label: 'Hold to reboot',
          icon: Icons.power_settings_new,
          color: Colors.redAccent,
          onConfirmed: () {
            if (api != null) _action(api.reboot, 'Router reboot ho raha hai');
          },
        ),
        const SizedBox(height: 24),
      ],
    );
  }

  Widget _kv(String k, String v) {
    final t = context.watch<AppState>().theme;
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 3),
      child: Row(
        children: [
          SizedBox(width: 80, child: Text(k, style: TextStyle(color: t.sub))),
          Expanded(child: Text(v)),
        ],
      ),
    );
  }
}

class SparkPainter extends CustomPainter {
  final List<double> a;
  final List<double> b;
  final Color ca;
  final Color cb;
  SparkPainter(this.a, this.b, this.ca, this.cb);

  @override
  void paint(Canvas canvas, Size size) {
    double maxV = 1;
    for (final v in a) {
      if (v > maxV) maxV = v;
    }
    for (final v in b) {
      if (v > maxV) maxV = v;
    }
    void line(List<double> d, Color c) {
      if (d.length < 2) return;
      final path = Path();
      for (var i = 0; i < d.length; i++) {
        final x = size.width * (i + (_cap - d.length)) / (_cap - 1);
        final y = size.height - (d[i] / maxV) * (size.height - 4) - 2;
        if (i == 0) {
          path.moveTo(x, y);
        } else {
          path.lineTo(x, y);
        }
      }
      canvas.drawPath(
        path,
        Paint()
          ..color = c
          ..style = PaintingStyle.stroke
          ..strokeWidth = 2
          ..strokeJoin = StrokeJoin.round,
      );
    }

    line(a, ca);
    line(b, cb);
  }

  @override
  bool shouldRepaint(covariant SparkPainter oldDelegate) => true;
}

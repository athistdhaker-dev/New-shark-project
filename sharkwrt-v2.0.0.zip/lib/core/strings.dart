/// All user-facing text lives here so a translation (e.g. Hindi) can be added later
/// by swapping this one class for a locale-aware lookup.
class S {
  S._();

  // ---- common
  static const cancel = 'Cancel';
  static const ok = 'OK';
  static const save = 'Save';
  static const apply = 'Apply';
  static const discard = 'Discard';
  static const delete = 'Delete';
  static const edit = 'Edit';
  static const add = 'Add';
  static const retry = 'Retry';
  static const close = 'Close';
  static const yes = 'Yes';
  static const done = 'Done';
  static const refresh = 'Refresh';
  static const search = 'Search';
  static const copy = 'Copy';
  static const paste = 'Paste';
  static const share = 'Share';
  static const unknownDevice = 'Unknown device';
  static const notAvailable = 'Not available on this router';
  static const loading = 'Loading...';
  static const empty = '(empty)';

  // ---- terminal
  static const terminal = 'Terminal';
  static const termSnippets = 'Snippets';
  static const termHistory = 'History';
  static const termNewTab = 'New tab';
  static const termRenameTab = 'Rename tab';
  static const termReconnect = 'Reconnect';
  static const termDisconnected = 'Session disconnected';
  static const termConnecting = 'Connecting...';
  static const termJumpBottom = 'Jump to bottom';
  static const termCopyAll = 'Copy all output';
  static const termShareLog = 'Share session log';
  static const termSettings = 'Terminal settings';
  static const termFontSize = 'Font size';
  static const termLineHeight = 'Line height';
  static const termColorScheme = 'Color scheme';
  static const termConfirmDanger = 'Confirm dangerous commands';
  static const termConfirmDangerSub =
      'Asks before reboot, firstboot, sysupgrade, rm -rf / and similar';
  static const termStartup = 'Run on connect';
  static const termStartupHint = 'Command to run when a shell opens (optional)';
  static const termDangerTitle = 'Run this command?';
  static const termNewSnippet = 'New snippet';
  static const termEditSnippet = 'Edit snippet';
  static const termSnippetName = 'Name';
  static const termSnippetCmd = 'Command ({ip} = router address)';
  static const termSnippetHint = 'Tap = insert, long-press = run';
  static const termMySnippets = 'My snippets';
  static const termBuiltin = 'OpenWrt pack';
  static const termNoHistory = 'No commands yet';
  static const termClearHistory = 'Clear history';
  static const termTabClosed = '[session closed]';

  // ---- ssh
  static const sshNotConnected = 'Not connected';
  static const sshHostKeyChanged =
      'Host key changed (router reflashed?). Use "Reset host key" in the router menu.';
  static const sshAuthFailed = 'Login failed: check username, password or key.';
  static const sshTimeout = 'Could not reach the router (timeout). Check IP and Wi-Fi.';
  static const sshRouterSlow = 'Router did not answer in time';
  static const sshDropped = 'Connection dropped';
}

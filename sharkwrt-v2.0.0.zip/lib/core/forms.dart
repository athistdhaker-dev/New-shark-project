import 'package:flutter/material.dart';

class FField {
  final String label;
  final String initial;
  final bool obscure;
  final TextInputType? keyboard;
  const FField(this.label,
      [this.initial = '', this.obscure = false, this.keyboard]);
}

/// Simple multi-field dialog. Returns the trimmed values, or null on cancel.
Future<List<String>?> askForm(
  BuildContext context,
  String title,
  List<FField> fields, {
  String ok = 'Save',
  String? note,
}) {
  final cs = [for (final f in fields) TextEditingController(text: f.initial)];
  return showDialog<List<String>>(
    context: context,
    builder: (ctx) => AlertDialog(
      title: Text(title),
      content: SingleChildScrollView(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            if (note != null)
              Padding(
                padding: const EdgeInsets.only(bottom: 12),
                child: Text(note, style: const TextStyle(fontSize: 13)),
              ),
            for (var i = 0; i < fields.length; i++)
              Padding(
                padding: const EdgeInsets.only(bottom: 10),
                child: TextField(
                  controller: cs[i],
                  obscureText: fields[i].obscure,
                  keyboardType: fields[i].keyboard,
                  decoration: InputDecoration(labelText: fields[i].label),
                ),
              ),
          ],
        ),
      ),
      actions: [
        TextButton(
            onPressed: () => Navigator.pop(ctx), child: const Text('Cancel')),
        FilledButton(
          onPressed: () => Navigator.pop(ctx, [for (final c in cs) c.text.trim()]),
          child: Text(ok),
        ),
      ],
    ),
  );
}

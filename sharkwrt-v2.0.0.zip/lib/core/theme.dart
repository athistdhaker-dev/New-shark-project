import 'package:flutter/material.dart';

class SharkTheme {
  final String name;
  final bool dark;
  final List<Color> bg;
  final Color panel;
  final Color border;
  final Color text;
  final Color sub;
  const SharkTheme({
    required this.name,
    required this.dark,
    required this.bg,
    required this.panel,
    required this.border,
    required this.text,
    required this.sub,
  });
}

const List<SharkTheme> kThemes = [
  SharkTheme(
    name: 'Abyss',
    dark: true,
    bg: [Color(0xFF04070D), Color(0xFF0A1830), Color(0xFF062433)],
    panel: Color(0x1FFFFFFF),
    border: Color(0x33FFFFFF),
    text: Color(0xFFFFFFFF),
    sub: Color(0xB3FFFFFF),
  ),
  SharkTheme(
    name: 'Aurora',
    dark: true,
    bg: [Color(0xFF120A26), Color(0xFF2A1450), Color(0xFF0B3A44)],
    panel: Color(0x22FFFFFF),
    border: Color(0x38FFFFFF),
    text: Color(0xFFFFFFFF),
    sub: Color(0xB3FFFFFF),
  ),
  SharkTheme(
    name: 'Paper',
    dark: false,
    bg: [Color(0xFFF5F7FC), Color(0xFFE6ECF8), Color(0xFFEEF3FB)],
    panel: Color(0xB3FFFFFF),
    border: Color(0x1F000000),
    text: Color(0xFF111827),
    sub: Color(0xFF5B6475),
  ),
];

const List<Color> kAccents = [
  Color(0xFF4DA3FF),
  Color(0xFF2DD4BF),
  Color(0xFFA78BFA),
  Color(0xFFFB7185),
  Color(0xFFFBBF24),
  Color(0xFF34D399),
];

ThemeData buildTheme(SharkTheme t, Color accent) {
  final brightness = t.dark ? Brightness.dark : Brightness.light;
  final scheme = ColorScheme.fromSeed(seedColor: accent, brightness: brightness);
  final base = ThemeData(
    useMaterial3: true,
    colorScheme: scheme,
    brightness: brightness,
  );
  return base.copyWith(
    scaffoldBackgroundColor: Colors.transparent,
    textTheme: base.textTheme.apply(bodyColor: t.text, displayColor: t.text),
    iconTheme: IconThemeData(color: t.text),
    dividerColor: t.border,
    appBarTheme: AppBarTheme(
      backgroundColor: Colors.transparent,
      elevation: 0,
      scrolledUnderElevation: 0,
      foregroundColor: t.text,
      centerTitle: false,
    ),
    navigationBarTheme: NavigationBarThemeData(
      backgroundColor:
          t.dark ? const Color(0xAA000000) : const Color(0xCCFFFFFF),
      indicatorColor: accent.withAlpha(90),
    ),
    inputDecorationTheme: InputDecorationTheme(
      filled: true,
      fillColor: t.panel,
      border: OutlineInputBorder(
        borderRadius: BorderRadius.circular(14),
        borderSide: BorderSide.none,
      ),
    ),
  );
}

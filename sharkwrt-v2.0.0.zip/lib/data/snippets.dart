import 'dart:convert';

class Snippet {
  final String id;
  final String name;
  final String cmd;
  final bool builtin;
  const Snippet(this.id, this.name, this.cmd, {this.builtin = false});

  Map<String, dynamic> toJson() => {'id': id, 'name': name, 'cmd': cmd};

  factory Snippet.fromJson(Map<String, dynamic> j) => Snippet(
        j['id'] as String,
        (j['name'] as String?) ?? '',
        (j['cmd'] as String?) ?? '',
      );

  /// Fills {ip} with the router address.
  String resolve(String routerHost) => cmd.replaceAll('{ip}', routerHost);
}

const List<Snippet> kBuiltinSnippets = [
  Snippet('b1', 'Board info', 'ubus call system board', builtin: true),
  Snippet('b2', 'Follow log', 'logread -f', builtin: true),
  Snippet('b3', 'Last 50 log lines', 'logread | tail -n 50', builtin: true),
  Snippet('b4', 'UCI wireless', 'uci show wireless', builtin: true),
  Snippet('b5', 'UCI network', 'uci show network', builtin: true),
  Snippet('b6', 'UCI firewall', 'uci show firewall', builtin: true),
  Snippet('b7', 'IP addresses', 'ip addr', builtin: true),
  Snippet('b8', 'Routes', 'ip route', builtin: true),
  Snippet('b9', 'Load average', 'cat /proc/loadavg', builtin: true),
  Snippet('b10', 'Memory', 'free -h', builtin: true),
  Snippet('b11', 'Disk usage', 'df -h', builtin: true),
  Snippet('b12', 'Top processes', 'top -b -n1 | head -20', builtin: true),
  Snippet('b13', 'Ping Cloudflare', 'ping -c 3 1.1.1.1', builtin: true),
  Snippet('b14', 'DNS lookup', 'nslookup openwrt.org', builtin: true),
  Snippet('b15', 'Upgradable packages (opkg)',
      'opkg update && opkg list-upgradable',
      builtin: true),
  Snippet('b16', 'Restart network', '/etc/init.d/network restart',
      builtin: true),
  Snippet('b17', 'Reload Wi-Fi', 'wifi reload', builtin: true),
  Snippet('b18', 'Wi-Fi info', 'iwinfo', builtin: true),
  Snippet('b19', 'DHCP leases', 'cat /tmp/dhcp.leases', builtin: true),
  Snippet('b20', 'Connection count', 'conntrack -L | wc -l', builtin: true),
  Snippet('b21', 'Ping router ({ip})', 'ping -c 3 {ip}', builtin: true),
];

List<Snippet> decodeSnippets(String? raw) {
  if (raw == null) return [];
  try {
    final l = jsonDecode(raw) as List;
    return l
        .map((e) => Snippet.fromJson(Map<String, dynamic>.from(e as Map)))
        .toList();
  } catch (_) {
    return [];
  }
}

String encodeSnippets(List<Snippet> l) =>
    jsonEncode(l.map((e) => e.toJson()).toList());

/// Commands that deserve a confirmation before they run in the terminal.
final RegExp kDangerousCommand = RegExp(
  r'(^|[;&|]\s*)(reboot|poweroff|halt|firstboot|sysupgrade|jffs2reset|mtd\s+(erase|write))\b|rm\s+(-\w+\s+)*(/|/\*|/etc|/overlay)(\s|$)',
);

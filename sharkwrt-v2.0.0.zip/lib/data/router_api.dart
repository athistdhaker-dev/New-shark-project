import 'dart:convert';

import '../core/uci.dart';
import 'ssh.dart';

class RouterInfo {
  String model = '';
  String release = '';
  String hostname = '';
  String wanDev = '';
  String wanProto = '';
  String wanIp = '';
  String dns = '';
  bool wanUp = false;
}

class Stats {
  double cpu = 0;
  double load = 0;
  int memTotal = 0; // kB
  int memUsed = 0; // kB
  int flashTotal = 0; // kB
  int flashUsed = 0; // kB
  double uptime = 0; // seconds
  final Map<String, List<int>> net = {}; // dev -> [rx, tx]
  DateTime at = DateTime.now();
}

class RadioInfo {
  final String name;
  final String band;
  final String channel;
  final String htmode;
  final bool disabled;
  RadioInfo(this.name, this.band, this.channel, this.htmode, this.disabled);
}

class WifiIface {
  final String section;
  final String device;
  final String ssid;
  final String encryption;
  final String key;
  final String mode;
  final bool disabled;
  WifiIface(this.section, this.device, this.ssid, this.encryption, this.key,
      this.mode, this.disabled);
}

class WifiData {
  final List<RadioInfo> radios;
  final List<WifiIface> ifaces;
  WifiData(this.radios, this.ifaces);
  String bandOf(String radio) {
    for (final r in radios) {
      if (r.name == radio) return r.band;
    }
    return '?';
  }
}

class NetClient {
  final String mac;
  String ip;
  String hostname;
  String band; // 5G, 2.4G, LAN
  int? signal;
  NetClient(this.mac, this.ip, this.hostname, this.band, this.signal);
}

class ClientsData {
  final List<NetClient> clients;
  final Map<String, String> blocked; // mac -> name
  ClientsData(this.clients, this.blocked);
}

class NetworkData {
  final UciConfig network;
  final UciConfig dhcp;
  NetworkData(this.network, this.dhcp);
}

class FirewallData {
  final UciConfig cfg;
  final List<String> changes;
  FirewallData(this.cfg, this.changes);
}

class ServiceItem {
  final String name;
  final bool enabled;
  ServiceItem(this.name, this.enabled);
}

class RouterApi {
  final SshSession ssh;
  RouterApi(this.ssh);

  String wanDev = '';
  int? _pTotal;
  int? _pIdle;

  static const String _wifiReload = '(wifi reload >/dev/null 2>&1 &)';

  Map<String, dynamic>? _json(String s) {
    try {
      final v = jsonDecode(s.trim());
      if (v is Map) return Map<String, dynamic>.from(v);
    } catch (_) {}
    return null;
  }

  String _sec(String s) {
    if (!isSafeName(s)) throw SshException('Galat section naam');
    return s;
  }

  String _mac(String s) {
    if (!isMac(s)) throw SshException('Galat MAC address');
    return s.toLowerCase();
  }

  String _digits(String s) {
    if (!RegExp(r'^\d+$').hasMatch(s)) throw SshException('Sirf number daalo');
    return s;
  }

  Future<String> run(String cmd) => ssh.run(cmd);

  // ---------------------------------------------------------------- info

  Future<RouterInfo> loadInfo() async {
    final out = await ssh.run(
        r'''ubus call system board 2>/dev/null; echo '@@'; ubus call network.interface.wan status 2>/dev/null''');
    final parts = out.split('@@');
    final b = _json(parts[0]);
    final w = parts.length > 1 ? _json(parts[1]) : null;
    final info = RouterInfo();
    if (b != null) {
      info.model = '${b['model'] ?? ''}';
      info.hostname = '${b['hostname'] ?? ''}';
      final r = b['release'];
      if (r is Map) info.release = '${r['description'] ?? ''}';
    }
    if (w != null) {
      info.wanDev = '${w['l3_device'] ?? w['device'] ?? ''}';
      info.wanProto = '${w['proto'] ?? ''}';
      final a = w['ipv4-address'];
      if (a is List && a.isNotEmpty && a.first is Map) {
        info.wanIp = '${(a.first as Map)['address'] ?? ''}';
      }
      final d = w['dns-server'];
      if (d is List) info.dns = d.join(', ');
      info.wanUp = w['up'] == true;
    }
    wanDev = info.wanDev;
    return info;
  }

  // --------------------------------------------------------------- stats

  static const String _statsCmd =
      r'''cat /proc/loadavg; echo '@@'; head -n1 /proc/stat; echo '@@'; grep -E '^(MemTotal|MemAvailable|MemFree|Buffers|Cached):' /proc/meminfo; echo '@@'; cat /proc/uptime; echo '@@'; (df -k /overlay 2>/dev/null || df -k /) | tail -n1; echo '@@'; cat /proc/net/dev''';

  Future<Stats> loadStats() async {
    final out = await ssh.run(_statsCmd);
    final parts = out.split('@@');
    if (parts.length < 6) throw SshException('Stats padh nahi paya');
    final st = Stats();
    st.load = double.tryParse(parts[0].trim().split(' ').first) ?? 0;

    final cl = parts[1].trim().split(RegExp(r'\s+'));
    if (cl.length > 5 && cl[0] == 'cpu') {
      final v = cl.sublist(1).map((e) => int.tryParse(e) ?? 0).toList();
      final total = v.take(8).fold<int>(0, (a, b) => a + b);
      final idle = v[3] + (v.length > 4 ? v[4] : 0);
      if (_pTotal != null && _pIdle != null) {
        final dt = total - _pTotal!;
        final di = idle - _pIdle!;
        if (dt > 0) st.cpu = ((dt - di) * 100 / dt).clamp(0, 100).toDouble();
      }
      _pTotal = total;
      _pIdle = idle;
    }

    final mem = <String, int>{};
    for (final l in parts[2].split('\n')) {
      final m = RegExp(r'^(\w+):\s+(\d+)').firstMatch(l.trim());
      if (m != null) mem[m.group(1)!] = int.parse(m.group(2)!);
    }
    st.memTotal = mem['MemTotal'] ?? 0;
    final avail = mem['MemAvailable'] ??
        ((mem['MemFree'] ?? 0) + (mem['Buffers'] ?? 0) + (mem['Cached'] ?? 0));
    st.memUsed = st.memTotal - avail;

    st.uptime = double.tryParse(parts[3].trim().split(' ').first) ?? 0;

    final df = parts[4].trim().split(RegExp(r'\s+'));
    if (df.length >= 4) {
      st.flashTotal = int.tryParse(df[1]) ?? 0;
      st.flashUsed = int.tryParse(df[2]) ?? 0;
    }

    for (final l in parts[5].split('\n')) {
      final i = l.indexOf(':');
      if (i < 0) continue;
      final dev = l.substring(0, i).trim();
      final c = l.substring(i + 1).trim().split(RegExp(r'\s+'));
      if (c.length >= 9) {
        st.net[dev] = [int.tryParse(c[0]) ?? 0, int.tryParse(c[8]) ?? 0];
      }
    }
    st.at = DateTime.now();
    return st;
  }

  // ---------------------------------------------------------------- wifi

  Future<WifiData> loadWifi() async {
    final out = await ssh.run('uci show wireless 2>/dev/null');
    final cfg = parseUciShow(out);
    final radios = cfg.ofType('wifi-device').map((s) {
      final ch = s.o('channel') ?? 'auto';
      var band = '?';
      final b = s.o('band');
      final hw = s.o('hwmode');
      if (b == '2g') {
        band = '2.4G';
      } else if (b == '5g') {
        band = '5G';
      } else if (b == '6g') {
        band = '6G';
      } else if (hw == '11g' || hw == '11b') {
        band = '2.4G';
      } else if (hw == '11a') {
        band = '5G';
      } else {
        final n = int.tryParse(ch);
        if (n != null) band = n <= 14 ? '2.4G' : '5G';
      }
      return RadioInfo(s.name, band, ch, s.o('htmode') ?? '', s.o('disabled') == '1');
    }).toList();
    final ifaces = cfg.ofType('wifi-iface').map((s) {
      return WifiIface(
        s.name,
        s.o('device') ?? '',
        s.o('ssid') ?? '',
        s.o('encryption') ?? 'none',
        s.o('key') ?? '',
        s.o('mode') ?? 'ap',
        s.o('disabled') == '1',
      );
    }).toList();
    return WifiData(radios, ifaces);
  }

  Future<void> updateIface(
    String section, {
    required String ssid,
    required String encryption,
    required String key,
    required bool disabled,
  }) async {
    final s = _sec(section);
    final b = StringBuffer();
    b.write('uci set wireless.$s.ssid=${shq(ssid)}');
    b.write(' && uci set wireless.$s.encryption=${shq(encryption)}');
    if (encryption == 'none') {
      b.write(' && (uci -q delete wireless.$s.key; true)');
    } else if (key.isNotEmpty) {
      b.write(' && uci set wireless.$s.key=${shq(key)}');
    }
    b.write(' && uci set wireless.$s.disabled=${disabled ? 1 : 0}');
    b.write(' && uci commit wireless && $_wifiReload');
    await ssh.run(b.toString());
  }

  Future<void> addIface({
    required String radio,
    required String ssid,
    required String encryption,
    required String key,
  }) async {
    final r = _sec(radio);
    final b = StringBuffer();
    b.write('S=\$(uci add wireless wifi-iface) && uci set wireless.\$S.device=$r');
    b.write(' && uci set wireless.\$S.mode=ap && uci set wireless.\$S.network=lan');
    b.write(' && uci set wireless.\$S.ssid=${shq(ssid)}');
    b.write(' && uci set wireless.\$S.encryption=${shq(encryption)}');
    if (encryption != 'none') {
      b.write(' && uci set wireless.\$S.key=${shq(key)}');
    }
    b.write(' && uci commit wireless && $_wifiReload');
    await ssh.run(b.toString());
  }

  Future<void> deleteIface(String section) async {
    final s = _sec(section);
    await ssh.run('uci delete wireless.$s && uci commit wireless && $_wifiReload');
  }

  Future<void> setRadio(String radio, {String? channel, bool? disabled}) async {
    final r = _sec(radio);
    final b = StringBuffer('true');
    if (channel != null) {
      if (channel != 'auto') _digits(channel);
      b.write(' && uci set wireless.$r.channel=${shq(channel)}');
    }
    if (disabled != null) {
      b.write(' && uci set wireless.$r.disabled=${disabled ? 1 : 0}');
    }
    b.write(' && uci commit wireless && $_wifiReload');
    await ssh.run(b.toString());
  }

  // ------------------------------------------------------------- clients

  static const String _clientsCmd =
      r'''echo '@@LEASES'; cat /tmp/dhcp.leases 2>/dev/null; echo '@@NEIGH'; ip neigh show 2>/dev/null; echo '@@WIFI'; for i in $(iw dev 2>/dev/null | awk '$1=="Interface"{print $2}'); do echo "IFACE $i"; iw dev $i info 2>/dev/null | grep channel; iw dev $i station dump 2>/dev/null; done; echo '@@FW'; uci show firewall 2>/dev/null | grep -E '^firewall\.swblk_'; true''';

  Future<ClientsData> loadClients() async {
    final out = await ssh.run(_clientsCmd);
    String section(String name) {
      final i = out.indexOf('@@$name');
      if (i < 0) return '';
      final start = out.indexOf('\n', i);
      if (start < 0) return '';
      final next = out.indexOf('@@', start);
      return out.substring(start + 1, next < 0 ? out.length : next);
    }

    // leases: expiry mac ip hostname clientid
    final names = <String, String>{};
    final leaseIp = <String, String>{};
    for (final l in section('LEASES').split('\n')) {
      final f = l.trim().split(RegExp(r'\s+'));
      if (f.length >= 4) {
        final mac = f[1].toLowerCase();
        leaseIp[mac] = f[2];
        if (f[3] != '*') names[mac] = f[3];
      }
    }

    // neighbours (IPv4 on bridge)
    final neighIp = <String, String>{};
    for (final l in section('NEIGH').split('\n')) {
      final f = l.trim().split(RegExp(r'\s+'));
      if (f.length < 5) continue;
      final ip = f[0];
      if (ip.contains(':')) continue;
      final di = f.indexOf('dev');
      final dev = (di >= 0 && di + 1 < f.length) ? f[di + 1] : '';
      final li = f.indexOf('lladdr');
      if (li < 0 || li + 1 >= f.length) continue;
      final state = f.last;
      if (state == 'FAILED' || state == 'INCOMPLETE') continue;
      if (!(dev.startsWith('br-') || dev == 'lan' || dev == 'br0')) continue;
      neighIp[f[li + 1].toLowerCase()] = ip;
    }

    final byMac = <String, NetClient>{};
    // wifi stations
    var band = '2.4G';
    String? curMac;
    for (final raw in section('WIFI').split('\n')) {
      final l = raw.trim();
      if (l.startsWith('IFACE ')) {
        band = '2.4G';
        curMac = null;
      } else if (l.startsWith('channel')) {
        final m = RegExp(r'\((\d+) MHz\)').firstMatch(l);
        if (m != null) {
          final mhz = int.parse(m.group(1)!);
          band = mhz >= 5925 ? '6G' : (mhz >= 3000 ? '5G' : '2.4G');
        }
      } else if (l.startsWith('Station ')) {
        final f = l.split(RegExp(r'\s+'));
        if (f.length >= 2) {
          final mac = f[1].toLowerCase();
          curMac = mac;
          byMac[mac] = NetClient(
            mac,
            neighIp[mac] ?? leaseIp[mac] ?? '',
            names[mac] ?? '',
            band,
            null,
          );
        }
      } else if (curMac != null && l.startsWith('signal:')) {
        final m = RegExp(r'signal:\s*(-?\d+)').firstMatch(l);
        if (m != null) byMac[curMac]?.signal = int.parse(m.group(1)!);
      }
    }
    // wired
    neighIp.forEach((mac, ip) {
      if (!byMac.containsKey(mac)) {
        byMac[mac] = NetClient(mac, ip, names[mac] ?? '', 'LAN', null);
      }
    });

    final list = byMac.values.toList()
      ..sort((a, b) => a.ip.compareTo(b.ip));

    // blocked
    final blocked = <String, String>{};
    for (final l in section('FW').split('\n')) {
      final m = RegExp(r"^firewall\.swblk_\w+\.src_mac='([0-9A-Fa-f:]{17})'")
          .firstMatch(l.trim());
      if (m != null) {
        final mac = m.group(1)!.toLowerCase();
        blocked[mac] = names[mac] ?? '';
      }
    }
    return ClientsData(list, blocked);
  }

  Future<void> blockMac(String mac, {String ip = ''}) async {
    final m = _mac(mac);
    final sec = 'swblk_${m.replaceAll(':', '')}';
    final b = StringBuffer();
    b.write('uci set firewall.$sec=rule');
    b.write(' && uci set firewall.$sec.name=${shq('SharkWRT block $m')}');
    b.write(' && uci set firewall.$sec.src=lan');
    b.write(' && uci set firewall.$sec.src_mac=$m');
    b.write(' && uci set firewall.$sec.dest=wan');
    b.write(' && uci set firewall.$sec.target=REJECT');
    b.write(' && uci commit firewall && /etc/init.d/firewall reload >/dev/null 2>&1');
    if (RegExp(r'^\d+\.\d+\.\d+\.\d+$').hasMatch(ip)) {
      b.write('; conntrack -D -s $ip >/dev/null 2>&1; true');
    }
    await ssh.run(b.toString());
  }

  Future<void> unblockMac(String mac) async {
    final m = _mac(mac);
    final sec = 'swblk_${m.replaceAll(':', '')}';
    await ssh.run(
        'uci -q delete firewall.$sec; uci commit firewall && /etc/init.d/firewall reload >/dev/null 2>&1');
  }

  // ------------------------------------------------------------- network

  Future<NetworkData> loadNetwork() async {
    final out = await ssh.run(
        r'''uci show network 2>/dev/null; echo '@@'; uci show dhcp 2>/dev/null''');
    final parts = out.split('@@');
    return NetworkData(
      parseUciShow(parts[0]),
      parseUciShow(parts.length > 1 ? parts[1] : ''),
    );
  }

  Future<void> setLan({required String ipaddr, String? netmask}) async {
    final b = StringBuffer('uci set network.lan.ipaddr=${shq(ipaddr)}');
    if (netmask != null && netmask.isNotEmpty) {
      b.write(' && uci set network.lan.netmask=${shq(netmask)}');
    }
    b.write(' && uci commit network && (/etc/init.d/network reload >/dev/null 2>&1 &)');
    await ssh.run(b.toString());
  }

  Future<void> setDhcp({
    required String start,
    required String limit,
    required String leasetime,
  }) async {
    _digits(start);
    _digits(limit);
    final b = StringBuffer('uci set dhcp.lan.start=$start');
    b.write(' && uci set dhcp.lan.limit=$limit');
    b.write(' && uci set dhcp.lan.leasetime=${shq(leasetime)}');
    b.write(' && uci commit dhcp && /etc/init.d/dnsmasq restart >/dev/null 2>&1');
    await ssh.run(b.toString());
  }

  Future<void> setWan({
    required String proto,
    String username = '',
    String password = '',
    String ipaddr = '',
    String netmask = '',
    String gateway = '',
    String dns = '',
    String macaddr = '',
  }) async {
    if (!['dhcp', 'static', 'pppoe'].contains(proto)) {
      throw SshException('Galat WAN protocol');
    }
    final b = StringBuffer('uci set network.wan.proto=$proto');
    for (final k in ['username', 'password', 'ipaddr', 'netmask', 'gateway']) {
      if (proto == 'pppoe' && (k == 'username' || k == 'password')) continue;
      b.write('; uci -q delete network.wan.$k');
    }
    if (proto == 'pppoe') {
      b.write('; uci set network.wan.username=${shq(username)}');
      if (password.isNotEmpty) {
        b.write('; uci set network.wan.password=${shq(password)}');
      }
    } else if (proto == 'static') {
      b.write('; uci set network.wan.ipaddr=${shq(ipaddr)}');
      b.write('; uci set network.wan.netmask=${shq(netmask)}');
      b.write('; uci set network.wan.gateway=${shq(gateway)}');
    }
    b.write('; uci -q delete network.wan.dns; uci -q delete network.wan.peerdns');
    final servers = dns.split(RegExp(r'[\s,]+')).where((e) => e.isNotEmpty);
    if (servers.isNotEmpty) {
      for (final d in servers) {
        if (!RegExp(r'^[0-9a-fA-F:.]+$').hasMatch(d)) {
          throw SshException('Galat DNS: $d');
        }
        b.write('; uci add_list network.wan.dns=$d');
      }
      b.write('; uci set network.wan.peerdns=0');
    }
    b.write('; uci -q delete network.wan.macaddr');
    if (macaddr.isNotEmpty) {
      b.write('; uci set network.wan.macaddr=${_mac(macaddr)}');
    }
    b.write('; uci commit network && (/etc/init.d/network reload >/dev/null 2>&1 &)');
    await ssh.run(b.toString());
  }

  Future<void> addStaticLease(String name, String mac, String ip) async {
    final m = _mac(mac);
    if (!RegExp(r'^\d+\.\d+\.\d+\.\d+$').hasMatch(ip)) {
      throw SshException('Galat IP');
    }
    final b = StringBuffer(r'S=$(uci add dhcp host) && uci set dhcp.$S.mac=');
    b.write(m);
    b.write(r' && uci set dhcp.$S.ip=');
    b.write(ip);
    if (name.isNotEmpty) b.write(' && uci set dhcp.\$S.name=${shq(name)}');
    b.write(' && uci commit dhcp && /etc/init.d/dnsmasq restart >/dev/null 2>&1');
    await ssh.run(b.toString());
  }

  Future<void> deleteStaticLease(String section) async {
    final s = _sec(section);
    await ssh.run(
        'uci delete dhcp.$s && uci commit dhcp && /etc/init.d/dnsmasq restart >/dev/null 2>&1');
  }

  Future<String> pingTest() => ssh.run(
      'ping -c 3 -W 2 1.1.1.1 2>&1; echo ---; ping -c 2 -W 2 google.com 2>&1',
      timeout: const Duration(seconds: 30));

  // ------------------------------------------------------------ firewall

  Future<FirewallData> loadFirewall() async {
    final out = await ssh.run(
        r'''uci show firewall 2>/dev/null; echo '@@'; uci changes firewall 2>/dev/null''');
    final parts = out.split('@@');
    final changes = (parts.length > 1 ? parts[1] : '')
        .split('\n')
        .map((e) => e.trim())
        .where((e) => e.isNotEmpty)
        .toList();
    return FirewallData(parseUciShow(parts[0]), changes);
  }

  Future<void> addPortForward({
    required String name,
    required String proto,
    required String extPort,
    required String destIp,
    required String destPort,
  }) async {
    if (!['tcp', 'udp', 'tcp udp'].contains(proto)) {
      throw SshException('Galat protocol');
    }
    if (!RegExp(r'^\d+\.\d+\.\d+\.\d+$').hasMatch(destIp)) {
      throw SshException('Galat IP');
    }
    if (!RegExp(r'^\d+(-\d+)?$').hasMatch(extPort) ||
        !RegExp(r'^\d+(-\d+)?$').hasMatch(destPort)) {
      throw SshException('Galat port');
    }
    final b = StringBuffer(r'S=$(uci add firewall redirect)');
    b.write(' && uci set firewall.\$S.name=${shq(name)}');
    b.write(r' && uci set firewall.$S.target=DNAT');
    b.write(r' && uci set firewall.$S.src=wan');
    b.write(r' && uci set firewall.$S.dest=lan');
    b.write(' && uci set firewall.\$S.proto=${shq(proto)}');
    b.write(' && uci set firewall.\$S.src_dport=$extPort');
    b.write(' && uci set firewall.\$S.dest_ip=$destIp');
    b.write(' && uci set firewall.\$S.dest_port=$destPort');
    await ssh.run(b.toString());
  }

  Future<void> addTrafficRule({
    required String name,
    required String proto,
    required String destPort,
    required String target,
  }) async {
    if (!['tcp', 'udp', 'tcp udp'].contains(proto)) {
      throw SshException('Galat protocol');
    }
    if (!['ACCEPT', 'REJECT', 'DROP'].contains(target)) {
      throw SshException('Galat action');
    }
    if (!RegExp(r'^\d+(-\d+)?$').hasMatch(destPort)) {
      throw SshException('Galat port');
    }
    final b = StringBuffer(r'S=$(uci add firewall rule)');
    b.write(' && uci set firewall.\$S.name=${shq(name)}');
    b.write(r' && uci set firewall.$S.src=wan');
    b.write(' && uci set firewall.\$S.proto=${shq(proto)}');
    b.write(' && uci set firewall.\$S.dest_port=$destPort');
    b.write(' && uci set firewall.\$S.target=$target');
    await ssh.run(b.toString());
  }

  Future<void> fwToggle(String section, bool enabled) async {
    final s = _sec(section);
    await ssh.run('uci set firewall.$s.enabled=${enabled ? 1 : 0}');
  }

  Future<void> fwDelete(String section) async {
    final s = _sec(section);
    await ssh.run('uci delete firewall.$s');
  }

  Future<void> fwApply() => ssh.run(
      'uci commit firewall && /etc/init.d/firewall reload >/dev/null 2>&1');

  Future<void> fwDiscard() => ssh.run('uci revert firewall');

  // -------------------------------------------------------------- system

  Future<void> reboot() =>
      ssh.run('(sleep 1; reboot) >/dev/null 2>&1 &');

  Future<void> restartWifi() => ssh.run(_wifiReload);

  Future<void> restartNetwork() =>
      ssh.run('(/etc/init.d/network restart >/dev/null 2>&1 &)');

  Future<void> setHostname(String h) async {
    if (!RegExp(r'^[A-Za-z0-9][A-Za-z0-9\-]{0,62}$').hasMatch(h)) {
      throw SshException('Hostname: sirf letters, numbers, "-"');
    }
    await ssh.run(
        'uci set system.@system[0].hostname=${shq(h)} && uci commit system && /etc/init.d/system reload >/dev/null 2>&1');
  }

  Future<List<ServiceItem>> loadServices() async {
    final out = await ssh.run(
        r'''for s in /etc/init.d/*; do n=$(basename $s); if $s enabled >/dev/null 2>&1; then echo "$n 1"; else echo "$n 0"; fi; done''',
        timeout: const Duration(seconds: 40));
    final list = <ServiceItem>[];
    for (final l in out.split('\n')) {
      final f = l.trim().split(' ');
      if (f.length == 2) list.add(ServiceItem(f[0], f[1] == '1'));
    }
    return list;
  }

  Future<void> serviceAction(String name, String action) async {
    if (!RegExp(r'^[A-Za-z0-9_\-.]+$').hasMatch(name)) {
      throw SshException('Galat service naam');
    }
    if (!['start', 'stop', 'restart', 'enable', 'disable'].contains(action)) {
      throw SshException('Galat action');
    }
    await ssh.run('/etc/init.d/$name $action >/dev/null 2>&1');
  }

  Future<String> logs() => ssh.run('logread 2>&1 | tail -n 200');

  Future<String> exec(String cmd) => ssh.run(
      'sh -c ${shq(cmd)} 2>&1',
      timeout: const Duration(seconds: 40));
}

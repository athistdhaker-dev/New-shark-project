import 'dart:async';
import 'dart:convert';
import 'dart:typed_data';

import 'package:dartssh2/dartssh2.dart';
import 'package:flutter/foundation.dart';
import 'package:xterm/xterm.dart';

import '../core/strings.dart';
import 'snippets.dart';
import 'ssh.dart';

enum TermState { connecting, connected, closed }

/// One interactive shell (its own PTY channel) plus its xterm emulator.
class TermTab extends ChangeNotifier {
  TermTab({
    required this.id,
    required this.title,
    required this.ssh,
    required this.onCommand,
    required this.confirmDanger,
    required this.wantConfirm,
    required this.startupCommand,
  }) {
    terminal = Terminal(maxLines: 10000);
    controller = TerminalController();
    terminal.onOutput = _onUserInput;
    terminal.onResize = (w, h, pw, ph) {
      _shell?.resizeTerminal(w, h);
    };
  }

  final int id;
  String title;
  final SshSession ssh;

  /// Called with every command line the user submits (for history).
  final void Function(String cmd) onCommand;

  /// Asks the user to confirm a dangerous command. true = run it.
  final Future<bool> Function(String cmd) confirmDanger;
  final bool Function() wantConfirm;
  final String Function() startupCommand;

  late final Terminal terminal;
  late final TerminalController controller;

  /// Sticky modifiers from the special-keys bar: they apply to the next key only.
  final ValueNotifier<bool> ctrl = ValueNotifier<bool>(false);
  final ValueNotifier<bool> alt = ValueNotifier<bool>(false);

  TermState state = TermState.connecting;
  String? error;

  SSHSession? _shell;
  StreamSubscription<String>? _outSub;
  StreamSubscription<String>? _errSub;
  bool _closing = false;
  bool _everOpened = false;

  // Rough tracking of the line being typed, for history and the danger check.
  final StringBuffer _line = StringBuffer();
  bool _lineValid = true;

  bool get connected => state == TermState.connected;

  Future<void> start() async {
    state = TermState.connecting;
    error = null;
    notifyListeners();
    await _detach();
    try {
      final sh = await ssh.openShell(
        terminal.viewWidth > 0 ? terminal.viewWidth : 80,
        terminal.viewHeight > 0 ? terminal.viewHeight : 24,
      );
      _shell = sh;
      _outSub = sh.stdout
          .cast<List<int>>()
          .transform(const Utf8Decoder(allowMalformed: true))
          .listen(terminal.write);
      _errSub = sh.stderr
          .cast<List<int>>()
          .transform(const Utf8Decoder(allowMalformed: true))
          .listen(terminal.write);
      unawaited(sh.done.then((_) => _onClosed()).catchError((Object _) {
        _onClosed();
      }));
      state = TermState.connected;
      if (_everOpened) {
        terminal.write('\r\n\x1b[32m[reconnected]\x1b[0m\r\n');
      } else {
        final startup = startupCommand().trim();
        if (startup.isNotEmpty) _send('$startup\r');
      }
      _everOpened = true;
    } catch (e) {
      state = TermState.closed;
      error = e.toString();
    }
    notifyListeners();
  }

  void _onClosed() {
    if (_closing || state == TermState.closed) return;
    state = TermState.closed;
    terminal.write('\r\n\x1b[31m${S.termTabClosed}\x1b[0m\r\n');
    notifyListeners();
  }

  Future<void> reconnect() async {
    try {
      if (!ssh.connected) await ssh.connect();
    } catch (e) {
      state = TermState.closed;
      error = e.toString();
      notifyListeners();
      return;
    }
    await start();
  }

  Future<void> _detach() async {
    await _outSub?.cancel();
    await _errSub?.cancel();
    _outSub = null;
    _errSub = null;
    try {
      _shell?.close();
    } catch (_) {}
    _shell = null;
  }

  // ------------------------------------------------------------------ input

  void _send(String s) {
    final sh = _shell;
    if (sh == null || state != TermState.connected) return;
    sh.write(Uint8List.fromList(utf8.encode(s)));
  }

  /// Everything typed (soft keyboard or keys bar) comes through here.
  void _onUserInput(String data) {
    if (_shell == null || state != TermState.connected) return;
    var out = data;
    if (ctrl.value && data.length == 1) {
      out = _applyCtrl(data);
      ctrl.value = false;
    } else if (alt.value && data.isNotEmpty && !data.startsWith('\x1b')) {
      out = '\x1b$data';
      alt.value = false;
    }
    final cr = out.indexOf('\r');
    if (cr >= 0 && wantConfirm() && !terminal.isUsingAltBuffer) {
      _submitWithCheck(out, cr);
      return;
    }
    _track(out);
    _send(out);
  }

  Future<void> _submitWithCheck(String out, int cr) async {
    final before = out.substring(0, cr);
    _track(before);
    final line = _line.toString().trim();
    final risky = _lineValid && line.isNotEmpty && kDangerousCommand.hasMatch(line);
    if (before.isNotEmpty) _send(before);
    if (risky) {
      final ok = await confirmDanger(line);
      if (!ok) {
        _send('\x15'); // Ctrl-U: clear the typed line
        _line.clear();
        _lineValid = true;
        return;
      }
    }
    final rest = out.substring(cr);
    _track(rest);
    _send(rest);
  }

  String _applyCtrl(String ch) {
    final c = ch.toUpperCase().codeUnitAt(0);
    if (c >= 0x40 && c <= 0x5f) return String.fromCharCode(c - 0x40);
    if (ch == ' ') return '\x00';
    if (ch == '?') return '\x7f';
    return ch;
  }

  void _track(String d) {
    if (terminal.isUsingAltBuffer) {
      _line.clear();
      _lineValid = true;
      return;
    }
    for (final r in d.runes) {
      if (r == 0x0d || r == 0x0a) {
        final cmd = _line.toString().trim();
        if (_lineValid && cmd.isNotEmpty) onCommand(cmd);
        _line.clear();
        _lineValid = true;
      } else if (r == 0x7f || r == 0x08) {
        final s = _line.toString();
        if (s.isNotEmpty) {
          _line.clear();
          _line.write(String.fromCharCodes(s.runes.take(s.runes.length - 1)));
        }
      } else if (r == 0x03 || r == 0x15 || r == 0x04) {
        _line.clear();
        _lineValid = true;
      } else if (r == 0x09) {
        _lineValid = false; // tab completion changes the line in ways we cannot see
      } else if (r < 0x20) {
        _lineValid = false; // escape sequences, cursor keys, etc.
      } else {
        _line.writeCharCode(r);
      }
    }
  }

  /// Types text (symbols from the keys bar, snippets, pasted text).
  void type(String s) => _onUserInput(s);

  /// Runs a full command line (adds Enter).
  void run(String cmd) {
    _onUserInput('$cmd\r');
  }

  /// Special keys that depend on terminal modes (arrows in vi/less, etc.).
  void key(TerminalKey k) {
    if (_shell == null || state != TermState.connected) return;
    final handled = terminal.keyInput(k, ctrl: ctrl.value, alt: alt.value);
    if (ctrl.value) ctrl.value = false;
    if (alt.value) alt.value = false;
    if (!handled) return;
    _lineValid = false;
  }

  /// Raw control byte, e.g. Ctrl-C.
  void raw(String s) {
    _track(s);
    _send(s);
  }

  void paste(String text) {
    if (_shell == null || state != TermState.connected) return;
    terminal.paste(text);
  }

  String fullText() => terminal.buffer.getText();

  Future<void> close() async {
    _closing = true;
    await _detach();
    state = TermState.closed;
  }

  @override
  void dispose() {
    _closing = true;
    _outSub?.cancel();
    _errSub?.cancel();
    try {
      _shell?.close();
    } catch (_) {}
    ctrl.dispose();
    alt.dispose();
    super.dispose();
  }
}

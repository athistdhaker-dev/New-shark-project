#!/usr/bin/env python3
"""Patches the freshly generated Flutter android/ folder for SharkWRT.

Usage: python3 tool/patch_android.py <project_dir>
- manifest: INTERNET permission, app label, allowBackup=false, no cleartext
- launcher icons: copies tool/icons/mipmap-*/ic_launcher.png
Fails loudly if something expected is missing.
"""
import os
import re
import shutil
import sys

root = sys.argv[1] if len(sys.argv) > 1 else "."
manifest = os.path.join(root, "android", "app", "src", "main", "AndroidManifest.xml")
res_dir = os.path.join(root, "android", "app", "src", "main", "res")

if not os.path.isfile(manifest):
    sys.exit("AndroidManifest.xml not found: " + manifest)

with open(manifest, encoding="utf-8") as f:
    xml = f.read()

# 1) INTERNET permission
if "android.permission.INTERNET" not in xml:
    xml = re.sub(
        r"(<application\b)",
        '<uses-permission android:name="android.permission.INTERNET"/>\n    \\1',
        xml,
        count=1,
    )

# 2) application attributes
m = re.search(r"<application\b[^>]*>", xml, re.S)
if not m:
    sys.exit("<application> tag not found")
tag = m.group(0)
new_tag = tag
for attr in ("android:label", "android:allowBackup", "android:usesCleartextTraffic"):
    new_tag = re.sub(r'\s+' + re.escape(attr) + r'="[^"]*"', "", new_tag)
new_tag = new_tag.replace(
    "<application",
    '<application\n        android:label="SharkWRT"\n'
    '        android:allowBackup="false"\n'
    '        android:usesCleartextTraffic="false"',
    1,
)
xml = xml.replace(tag, new_tag, 1)

with open(manifest, "w", encoding="utf-8") as f:
    f.write(xml)

# 3) icons
icons_src = os.path.join(root, "tool", "icons")
copied = 0
for d in sorted(os.listdir(icons_src)):
    src = os.path.join(icons_src, d, "ic_launcher.png")
    if not os.path.isfile(src):
        continue
    dst_dir = os.path.join(res_dir, d)
    os.makedirs(dst_dir, exist_ok=True)
    shutil.copyfile(src, os.path.join(dst_dir, "ic_launcher.png"))
    copied += 1
if copied == 0:
    sys.exit("no icons copied")

# 3b) minSdk 24 (flutter_secure_storage / local_auth need >= 23)
gradle_done = False
for gname in ("build.gradle.kts", "build.gradle"):
    gpath = os.path.join(root, "android", "app", gname)
    if not os.path.isfile(gpath):
        continue
    with open(gpath, encoding="utf-8") as f:
        g = f.read()
    g2 = re.sub(r"minSdk\s*=\s*flutter\.minSdkVersion", "minSdk = 24", g)
    g2 = re.sub(r"minSdkVersion\s+flutter\.minSdkVersion", "minSdkVersion 24", g2)
    if g2 != g:
        with open(gpath, "w", encoding="utf-8") as f:
            f.write(g2)
        gradle_done = True
    elif re.search(r"minSdk(Version)?\s*(=\s*)?\d+", g2):
        gradle_done = True
if not gradle_done:
    print("WARNING: could not set minSdk; check android/app/build.gradle")

# 4) verify
with open(manifest, encoding="utf-8") as f:
    out = f.read()
for needle in (
    "android.permission.INTERNET",
    'android:label="SharkWRT"',
    'android:allowBackup="false"',
    'android:usesCleartextTraffic="false"',
):
    if needle not in out:
        sys.exit("patch verification failed: missing " + needle)

print("android patch ok; icons copied:", copied)

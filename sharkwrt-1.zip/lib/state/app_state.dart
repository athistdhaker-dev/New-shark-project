import 'package:flutter/material.dart';

import '../core/theme.dart';
import '../data/models.dart';
import '../data/router_api.dart';
import '../data/ssh.dart';
import '../data/store.dart';

int _clampInt(int v, int max) => v < 0 ? 0 : (v > max ? max : v);

class AppState extends ChangeNotifier {
  final Store store = Store();
  List<RouterProfile> profiles = [];
  int themeIndex = 0;
  int accentIndex = 0;
  bool blur = true;

  RouterProfile? active;
  SshSession? session;
  RouterApi? api;
  RouterInfo info = RouterInfo();
  Map<String, String> _aliases = {};

  SharkTheme get theme => kThemes[_clampInt(themeIndex, kThemes.length - 1)];
  Color get accent => kAccents[_clampInt(accentIndex, kAccents.length - 1)];

  Future<void> init() async {
    await store.init();
    profiles = store.loadProfiles();
    themeIndex = store.prefs.getInt('theme') ?? 0;
    accentIndex = store.prefs.getInt('accent') ?? 0;
    blur = store.prefs.getBool('blur') ?? true;
  }

  Future<void> setTheme(int i) async {
    themeIndex = i;
    await store.prefs.setInt('theme', i);
    notifyListeners();
  }

  Future<void> setAccent(int i) async {
    accentIndex = i;
    await store.prefs.setInt('accent', i);
    notifyListeners();
  }

  Future<void> setBlur(bool v) async {
    blur = v;
    await store.prefs.setBool('blur', v);
    notifyListeners();
  }

  // ------------------------------------------------------------ profiles

  Future<void> saveProfile(RouterProfile p,
      {String? password, String? key}) async {
    final i = profiles.indexWhere((e) => e.id == p.id);
    if (i >= 0) {
      profiles[i] = p;
    } else {
      profiles.add(p);
    }
    await store.saveProfiles(profiles);
    if (password != null) await store.setSecret(p.id, 'pw', password);
    if (key != null) await store.setSecret(p.id, 'key', key);
    notifyListeners();
  }

  Future<void> deleteProfile(String id) async {
    profiles.removeWhere((e) => e.id == id);
    await store.saveProfiles(profiles);
    await store.deleteSecrets(id);
    await store.clearFingerprint(id);
    notifyListeners();
  }

  Future<void> resetHostKey(String id) => store.clearFingerprint(id);

  Future<String?> secret(String id, String kind) => store.secret(id, kind);

  // ---------------------------------------------------------- connection

  /// Returns an error message, or null on success.
  Future<String?> connect(RouterProfile p) async {
    final pw = await store.secret(p.id, 'pw');
    final key = await store.secret(p.id, 'key');
    final s = SshSession(profile: p, password: pw, privateKey: key, store: store);
    try {
      await s.connect();
      final a = RouterApi(s);
      RouterInfo i;
      try {
        i = await a.loadInfo();
      } catch (_) {
        i = RouterInfo();
      }
      session = s;
      api = a;
      info = i;
      active = p;
      _aliases = store.aliases(p.id);
      notifyListeners();
      return null;
    } catch (e) {
      await s.close();
      return e.toString();
    }
  }

  void disconnect() {
    session?.close();
    session = null;
    api = null;
    active = null;
    info = RouterInfo();
    notifyListeners();
  }

  // ------------------------------------------------------------- aliases

  String? alias(String mac) => _aliases[mac.toLowerCase()];

  Future<void> setAlias(String mac, String name) async {
    final p = active;
    if (p == null) return;
    if (name.isEmpty) {
      _aliases.remove(mac.toLowerCase());
    } else {
      _aliases[mac.toLowerCase()] = name;
    }
    await store.saveAliases(p.id, _aliases);
    notifyListeners();
  }
}

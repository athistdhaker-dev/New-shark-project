import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../core/ui.dart';
import '../state/app_state.dart';

class _Entry {
  final String cmd;
  String out;
  bool done;
  _Entry(this.cmd, this.out, this.done);
}

const List<String> _snippets = [
  'ubus call system board',
  'logread | tail -n 30',
  'ip addr show',
  'ip route',
  'cat /proc/loadavg',
  'free',
  'df -h',
  'ping -c 3 1.1.1.1',
  'uci show wireless | head -n 40',
  'opkg list-installed | head -n 40',
];

class TerminalScreen extends StatefulWidget {
  const TerminalScreen({super.key});

  @override
  State<TerminalScreen> createState() => _TerminalScreenState();
}

class _TerminalScreenState extends State<TerminalScreen> {
  final TextEditingController _c = TextEditingController();
  final ScrollController _sc = ScrollController();
  final List<_Entry> _log = [];
  bool _running = false;

  @override
  void dispose() {
    _c.dispose();
    _sc.dispose();
    super.dispose();
  }

  Future<void> _run(String cmd) async {
    final text = cmd.trim();
    if (text.isEmpty || _running) return;
    final api = context.read<AppState>().api;
    if (api == null) return;
    final e = _Entry(text, 'running...', false);
    setState(() {
      _log.add(e);
      _running = true;
      _c.clear();
    });
    try {
      final out = await api.exec(text);
      e.out = out.trimRight().isEmpty ? '(no output)' : out.trimRight();
    } catch (err) {
      e.out = 'ERROR: $err';
    }
    e.done = true;
    if (!mounted) return;
    setState(() => _running = false);
    await Future<void>.delayed(const Duration(milliseconds: 100));
    if (_sc.hasClients) {
      _sc.animateTo(
        _sc.position.maxScrollExtent,
        duration: const Duration(milliseconds: 200),
        curve: Curves.easeOut,
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    final t = context.watch<AppState>().theme;
    final accent = context.watch<AppState>().accent;
    return GlassScaffold(
      title: 'Terminal',
      actions: [
        IconButton(
          icon: const Icon(Icons.delete_sweep_outlined),
          onPressed: () => setState(_log.clear),
        ),
      ],
      body: Column(
        children: [
          Expanded(
            child: _log.isEmpty
                ? Center(
                    child: Text('Neeche se command likho ya snippet chuno',
                        style: TextStyle(color: t.sub)),
                  )
                : ListView.builder(
                    controller: _sc,
                    padding: const EdgeInsets.all(12),
                    itemCount: _log.length,
                    itemBuilder: (_, i) {
                      final e = _log[i];
                      return Padding(
                        padding: const EdgeInsets.only(bottom: 12),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text('# ${e.cmd}',
                                style: TextStyle(
                                    fontFamily: 'monospace',
                                    fontWeight: FontWeight.w700,
                                    color: accent)),
                            const SizedBox(height: 4),
                            SelectableText(e.out,
                                style: const TextStyle(
                                    fontFamily: 'monospace', fontSize: 12)),
                          ],
                        ),
                      );
                    },
                  ),
          ),
          SizedBox(
            height: 40,
            child: ListView(
              scrollDirection: Axis.horizontal,
              padding: const EdgeInsets.symmetric(horizontal: 12),
              children: [
                for (final s in _snippets)
                  Padding(
                    padding: const EdgeInsets.only(right: 8),
                    child: ActionChip(
                      label: Text(s, style: const TextStyle(fontSize: 12)),
                      onPressed: () => _c.text = s,
                    ),
                  ),
              ],
            ),
          ),
          Padding(
            padding: const EdgeInsets.all(12),
            child: Row(
              children: [
                Expanded(
                  child: TextField(
                    controller: _c,
                    autocorrect: false,
                    enableSuggestions: false,
                    style: const TextStyle(fontFamily: 'monospace'),
                    onSubmitted: _run,
                    decoration: const InputDecoration(hintText: 'command...'),
                  ),
                ),
                const SizedBox(width: 8),
                IconButton.filled(
                  onPressed: _running ? null : () => _run(_c.text),
                  icon: const Icon(Icons.send),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

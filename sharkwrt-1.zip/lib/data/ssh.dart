import 'dart:async';
import 'dart:convert';

import 'package:dartssh2/dartssh2.dart';

import 'models.dart';
import 'store.dart';

class SshException implements Exception {
  final String message;
  SshException(this.message);
  @override
  String toString() => message;
}

class SshSession {
  final RouterProfile profile;
  final String? password;
  final String? privateKey;
  final Store store;
  SSHClient? _client;
  bool _hostKeyMismatch = false;

  SshSession({
    required this.profile,
    required this.password,
    required this.privateKey,
    required this.store,
  });

  bool get connected => _client != null;

  Future<void> connect() async {
    await close();
    _hostKeyMismatch = false;
    try {
      final socket = await SSHSocket.connect(
        profile.host,
        profile.port,
        timeout: const Duration(seconds: 8),
      );
      final client = SSHClient(
        socket,
        username: profile.user,
        onPasswordRequest: () => password ?? '',
        identities: (profile.useKey && privateKey != null)
            ? SSHKeyPair.fromPem(privateKey!)
            : null,
        onVerifyHostKey: (type, fingerprint) async {
          final fp = fingerprint
              .map((b) => b.toRadixString(16).padLeft(2, '0'))
              .join(':');
          final saved = store.fingerprint(profile.id);
          if (saved == null) {
            await store.setFingerprint(profile.id, fp);
            return true;
          }
          if (saved == fp) return true;
          _hostKeyMismatch = true;
          return false;
        },
        keepAliveInterval: const Duration(seconds: 10),
      );
      await client.authenticated;
      _client = client;
    } catch (e) {
      if (_hostKeyMismatch) {
        throw SshException(
            'Host key badal gaya (router reflash hua?). Router list me menu se "Host key reset" karo.');
      }
      final m = e.toString();
      if (m.contains('Auth') || m.contains('auth')) {
        throw SshException('Login fail: username / password / key check karo.');
      }
      if (e is TimeoutException || m.contains('Timeout')) {
        throw SshException('Router se connect nahi hua (timeout). IP aur WiFi check karo.');
      }
      throw SshException('Connect nahi hua: $m');
    }
  }

  Future<String> run(String cmd,
      {Duration timeout = const Duration(seconds: 25)}) async {
    if (_client == null) await connect();
    final c = _client;
    if (c == null) throw SshException('Connected nahi hai');
    try {
      final bytes = await c.run(cmd).timeout(timeout);
      return utf8.decode(bytes, allowMalformed: true);
    } on TimeoutException {
      throw SshException('Router ne time par jawab nahi diya');
    } catch (e) {
      if (e is SshException) rethrow;
      _client = null;
      throw SshException('Connection toot gaya: $e');
    }
  }

  Future<void> close() async {
    try {
      _client?.close();
    } catch (_) {}
    _client = null;
  }
}

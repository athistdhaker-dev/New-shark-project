import 'dart:convert';

import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'package:shared_preferences/shared_preferences.dart';

import 'models.dart';

class Store {
  static const FlutterSecureStorage _sec = FlutterSecureStorage();
  late SharedPreferences prefs;

  Future<void> init() async {
    prefs = await SharedPreferences.getInstance();
  }

  List<RouterProfile> loadProfiles() {
    final raw = prefs.getString('profiles');
    if (raw == null) return [];
    try {
      final l = jsonDecode(raw) as List;
      return l
          .map((e) => RouterProfile.fromJson(Map<String, dynamic>.from(e as Map)))
          .toList();
    } catch (_) {
      return [];
    }
  }

  Future<void> saveProfiles(List<RouterProfile> l) => prefs.setString(
      'profiles', jsonEncode(l.map((e) => e.toJson()).toList()));

  Future<String?> secret(String id, String kind) async {
    try {
      return await _sec.read(key: '${kind}_$id');
    } catch (_) {
      return null;
    }
  }

  Future<void> setSecret(String id, String kind, String value) async {
    if (value.isEmpty) {
      await _sec.delete(key: '${kind}_$id');
    } else {
      await _sec.write(key: '${kind}_$id', value: value);
    }
  }

  Future<void> deleteSecrets(String id) async {
    try {
      await _sec.delete(key: 'pw_$id');
      await _sec.delete(key: 'key_$id');
    } catch (_) {}
  }

  String? fingerprint(String id) => prefs.getString('fp_$id');
  Future<void> setFingerprint(String id, String v) =>
      prefs.setString('fp_$id', v);
  Future<void> clearFingerprint(String id) => prefs.remove('fp_$id');

  Map<String, String> aliases(String id) {
    final raw = prefs.getString('alias_$id');
    if (raw == null) return {};
    try {
      return Map<String, String>.from(jsonDecode(raw) as Map);
    } catch (_) {
      return {};
    }
  }

  Future<void> saveAliases(String id, Map<String, String> m) =>
      prefs.setString('alias_$id', jsonEncode(m));
}
